# v4.23.46 — Fixed Live Caption and multilingual Live Translate

- Whisper output fixed: the -np (no prints) flag prevented recognized subtitles from appearing.
- Live Caption and Live Translate now retain their checkbox state when a model, stream, or network fails, show errors and offer Retry.
- English-only Live Translate menu replaced by 15 target languages (Vietnamese default).
- Auto-install missing Whisper and Argos offline language models only on first use. English can be translated directly by Whisper.
- Live Caption keeps its native transcription path. Live Translate displays actual translated subtitles from Argos.
- TTS receives the English intermediate and separately translates to its own voice language; source-volume ducking unchanged.
- Existing channel browser, player layout, IPTV, EPG, Mac Intel/Apple Silicon and Windows functions retained.
- Beta limitations: FFmpeg may not access DRM or cookie-protected streams; Argos model availability varies. No UI-only fake translation.
