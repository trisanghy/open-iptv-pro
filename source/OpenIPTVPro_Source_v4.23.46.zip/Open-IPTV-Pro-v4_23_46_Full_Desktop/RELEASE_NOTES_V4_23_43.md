# v4.23.43 - Live Caption / Live Translate (beta)

Opt-in captions and English speech translation via the user-installed local whisper-cli and GGML multilingual model. Tools appear on player toolbar row 3 beside Screenshot/FFmpeg. No cloud speech API. Audio clips are transient and deleted. Chrome native caption UI is not part of Electron; subtitle cues in native PiP are best-effort only. Translation target is English only. Source video layout and Mac/Windows architectures are unchanged.
