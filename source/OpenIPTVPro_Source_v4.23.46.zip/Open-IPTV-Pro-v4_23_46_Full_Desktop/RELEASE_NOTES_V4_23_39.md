# Open IPTV Pro v4.23.39 — Full-width Adaptive Player

- Fix: video player frame now fills 100% of the available horizontal content area instead of being narrowed by a viewport-height clamp.
- Keep video aspect ratio based on source metadata (default 16:9), with no stretching and no overlay of playback controls.
- Preserve existing channel-list collapse and the two-row playback controls.
- Windows/macOS desktop code; separate GitHub build-source branch, main branch unchanged.
