# Open IPTV Pro v4.23.41 - Two-line EPG and approved player layout

- Restore approved top row: channel identity, Previous/Play-Pause/Stop/Next, visible green volume slider, PiP and fullscreen.
- EPG is two readable lines: currently playing programme first, next programme second. Moderate font size, programme names truncate on narrow windows.
- Stream selector, video-fit picker and favourite remain on the second toolbar row.
- Cast/AirPlay remains accessible under expanded tools, same button ID and callback.
- Video width and source aspect-ratio logic stay unchanged; playback controls never overlap video.
- Windows/macOS source; keep Apple Silicon/Intel native installers separate. No changes to main branch.
