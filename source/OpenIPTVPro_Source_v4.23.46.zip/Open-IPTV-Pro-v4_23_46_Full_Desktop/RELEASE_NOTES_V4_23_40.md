# Open IPTV Pro v4.23.40 — Classic Player Controls / Universal Mac / Windows

- Restore approved compact Play/Pause, Previous, Stop, Next, Volume, Cast/AirPlay, PiP and Fullscreen controls across UI themes.
- Responsive controls stay under video; full-width source-aspect frame remains unchanged.
- Support Mac universal arm64+x86_64 and Windows Setup + Portable from pinned source ZIP.
