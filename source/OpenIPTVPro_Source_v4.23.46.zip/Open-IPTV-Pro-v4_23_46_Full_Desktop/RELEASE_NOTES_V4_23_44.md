# v4.23.44 - Multilingual Offline Voice-over (beta)

Adds an opt-in TTS switch, target language picker, source-volume ducking (0/15/25/50/75/100%), and one-click managed installation on playback row three.
Whisper speech translation (English text) → Argos offline translation to selected target (if needed) → Piper local speech WAV. Audio output uses a separate audio element; IPTV source level is reduced only while speech plays, and restored afterwards and upon stopping/switching channels.
One-click setup downloads the pinned, checksum-verified uv bootstrap, a private Python 3.11 environment, Piper/Argos packages, the chosen Piper voice and English-target Argos language package. No administrator password is needed. Internet is required once per language and models are not included in the DMG.
This beta depends on the v4.23.43 Whisper caption pipeline already being set up. Piper voice licenses vary. Some protected streams, unavailable translation pairs, or offline downloads can fail and will report their errors. Mac Intel/Apple Silicon and Windows source retained; no change to main.
