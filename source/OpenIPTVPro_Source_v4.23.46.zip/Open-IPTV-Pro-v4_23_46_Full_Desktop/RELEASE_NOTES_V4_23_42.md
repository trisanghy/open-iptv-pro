# Open IPTV Pro v4.23.42 — Compact Cast and volume toolbar

- Cast / AirPlay moved to the top row immediately after the now-shorter volume slider.
- Previous, Play/Pause, Stop, Next, Volume, Cast/AirPlay, PiP and Fullscreen remain in one compact row at ordinary laptop widths.
- EPG stays two rows (current programme, then next programme) without the visible labels "Đang phát" and "Tiếp theo"; video-fit label "Khung hình" is hidden without removing the accessible name.
- Manual fallback-stream dropdown reduced in width and height.
- Video frame and source aspect ratio untouched. Windows/macOS source preserved, with separate arm64/x64 Mac installers.
