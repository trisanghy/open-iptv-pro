# Open IPTV Pro v4.23.47 — Whisper automatic installer hotfix

Root cause: pinned community OpenWhispr ZIPs contain whisper-cpp-darwin-arm64, whisper-cpp-darwin-x64 and whisper-cpp-win32-x64-cpu.exe, rather than whisper-cli or whisper-cli.exe.
The old installer incorrectly reported that the correct CPU executable was missing after extracting it.

Fix: detect and rename the actual executable to whisper-cli (or whisper-cli.exe), preserve adjacent DLLs on Windows, mark Mac binary executable, reuse a previously extracted file, and smoke-test --help after new download.
Previous Live Caption, 15-target-language Live Translate, local Piper TTS and source-volume controls remain unchanged.
Beta: successful packaging alone does not verify audio transcription against a real-world stream.
