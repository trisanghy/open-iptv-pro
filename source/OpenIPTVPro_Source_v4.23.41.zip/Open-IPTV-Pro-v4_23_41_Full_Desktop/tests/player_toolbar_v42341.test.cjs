'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=read('renderer/index.html'),css=read('renderer/player-toolbar-v42341.css');
test('v4.23.41 approved toolbar is loaded last and video remains separate',()=>{
 assert.ok(html.indexOf('player-toolbar-v42341.css')>html.indexOf('player-classic-controls-v42340.css'));
 assert.ok(html.indexOf('id="playerBox"')<html.indexOf('class="player-control-card"'));
 assert.match(css,/grid-template-columns:minmax\(180px,1\.12fr\)/);
});
test('v4.23.41 volume slider is in the top row and not hidden',()=>{
 const top=html.split('<div class="control-layout-top">')[1].split('<div class="control-layout-bottom">')[0];
 assert.match(top,/id="volume"/);assert.match(top,/id="playBtn"/);
 assert.match(css,/#page-tv \.player-control-card \.volume-controls #volume/);
 assert.match(css,/visibility:visible!important/);
});
test('v4.23.41 EPG shows exactly two stacked programme rows in moderate typography',()=>{
 const bottom=html.split('<div class="control-layout-bottom">')[1].split('<details class="playback-extra"')[0];
 for(const id of ['epgCurrent','epgNowName','epgNextName','epgNowTime','epgNextTime'])assert.match(bottom,new RegExp('id="'+id+'"'));
 assert.match(css,/\.epg-current-item::before\{content:"Đang phát"\}/);
 assert.match(css,/\.epg-next-item::before\{content:"Tiếp theo"\}/);
 assert.match(css,/grid-template-rows:minmax\(25px,auto\) minmax\(25px,auto\)/);
});
test('v4.23.41 Cast still available, outside main toolbar',()=>{
 const extra=html.split('<div class="playback-extra-inner">')[1].split('</div>')[0];
 assert.match(extra,/id="castBtn"/);
 assert.equal((html.match(/id="castBtn"/g)||[]).length,1);
});
