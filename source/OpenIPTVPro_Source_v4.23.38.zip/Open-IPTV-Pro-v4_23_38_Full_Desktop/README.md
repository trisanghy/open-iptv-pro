# Open IPTV Pro — Desktop v4.23.38

**Electron 38 / Chromium · macOS (Apple Silicon, Intel) · Windows**

[**Source ZIP v4.23.38**](source/OpenIPTVPro_Source_v4.23.38.zip) · [Changelog / release notes](RELEASE_NOTES_V4_23_37.md) · [Automatic Mac source build](https://raw.githubusercontent.com/trisanghy/open-iptv-pro/iptv-build-source/build-mac.sh)

This repository's `main` branch carries the desktop source for **4.23.38**, with a single downloadable source archive and screenshots of the latest two-row TV player layout.

## Giao diện mới nhất / Latest screenshots

![Player v4.23.38 — volume and playback controls](docs/images/OpenIPTVPro-v4.23.38-player-layout.jpg)

![Player with channel list v4.23.38](docs/images/OpenIPTVPro-v4.23.38-channel-list.jpg)

*Ảnh giao diện kiểm tra bằng Chromium, không phải ảnh xác nhận luồng truyền hình đang phát trực tiếp.*

### Thay đổi nổi bật / Highlights

- Trình phát có **hai hàng điều khiển**; âm lượng lên hàng trên cạnh điều khiển phát, Cast/AirPlay, PiP, fullscreen; EPG, khung hình, link dự phòng và yêu thích ở hàng dưới.
- Nút mở lại danh sách kênh giảm còn **một nửa kích thước**, giảm khoảng trống và mở rộng tối đa vùng video.
- Sidebar gộp có icon căn giữa và khoảng cách đồng đều; thu gọn danh sách kênh độc lập với sidebar.
- Sắp xếp thư mục và kênh bằng kéo thả; giữ **Shift** để chọn nhiều kênh.
- Cấu hình luồng kiểm tra, Snapshot, thời gian tua lại bằng các hộp chọn.
- Trên macOS, bản cập nhật DMG tải và xác minh thành công được mở trước khi ứng dụng thoát hoàn toàn.
- Giữ tính năng EPG, FFmpeg, Timeshift, DVR, Snapshot, Auto Failover và MultiView.

**Test:** 264 passed, 0 failed, 2 skipped (source checks). Việc đưa source lên `main` không đồng nghĩa đã phát hành DMG/EXE hoặc Release GitHub.

---

## v4.22.2 — Backup / Restore for Windows and macOS

**Tiếng Việt:** Bổ sung Sao lưu / Khôi phục trong sidebar và Cài đặt. Xuất file `.iptvbackup` gồm playlist, yêu thích, thư mục, cấu hình, EPG và tùy chọn ảnh Snapshot. Khi khôi phục, ứng dụng kiểm tra dữ liệu, xem trước và xác nhận, tránh ghi đè ảnh cũ và rollback cấu hình nếu lỗi. File sao lưu chưa mã hóa. Xem `HUONG_DAN_BACKUP_RESTORE_V4_22_2.md`.

**English:** Desktop Backup/Restore exports playlists, favorites, groups, settings, EPG and optional Snapshot images into a local `.iptvbackup` file. Imports are validated and require confirmation; images are restored under non-colliding names and settings are rolled back on failure. Backup files are not encrypted.

**Cập nhật mã nguồn GitHub trên Mac:** chạy `bash ~/Downloads/CAP_NHAT_GITHUB_V4_22_2_MAC.command` sau khi tải ZIP mã nguồn và script vào Downloads. Script kiểm tra test, đăng nhập GitHub qua `gh`, đồng bộ mã nguồn desktop lên repository `trisanghy/open-iptv-pro` sau xác nhận. Không force-push, không sửa iOS/Android, không tự tạo Release.

---

## v4.22 Full – Cập nhật và bộ biểu tượng macOS

**Tiếng Việt:** Repository phát hành chính thức `trisanghy/open-iptv-pro` được cố định, không cần nhập lại. Ứng dụng đọc phiên bản từ tên bộ cài / tag / tên Release, tìm bản mới đúng hệ điều hành & kiến trúc (Mac Apple Silicon, Mac Intel hoặc Windows), tự tải khi bật tùy chọn, xác minh trước khi cài. Mac chưa ký dùng bộ cài DMG thủ công; ứng dụng ký đúng chuẩn có thể dùng trình tự cài tự động. Menu thay bằng 12 icon SVG nét bo tròn đồng nhất, giữ logo ứng dụng và toàn bộ FFmpeg/Timeshift Full.

**English:** The official release repository `trisanghy/open-iptv-pro` is built in. Version checks accept flexible release tag naming and locate a compatible newer installer for macOS ARM64, macOS Intel or Windows. Downloads are integrity-checked; signed eligible builds may install automatically after confirmation, while unsigned macOS builds open a verified DMG for manual installation. The sidebar now uses a consistent macOS-inspired SVG icon set. FFmpeg, Timeshift and all Full features remain included.

**Important:** Pushing source to GitHub does not publish installers. Release assets are required for updates. macOS automatic in-place installation requires a properly signed application. No Apple-owned SF Symbols files or fonts are bundled.

## Bản sửa v4.21.1: Phát hiện TV AirPlay trên macOS

Mục Google Cast chỉ phát hiện Chromecast/Google TV hỗ trợ Google Cast. Mục AirPlay trên Mac giờ có nút **Tìm thiết bị AirPlay**, dùng Bonjour (`dns-sd`) của macOS để hiển thị thiết bị tương thích. Để phát AirPlay, vẫn nhấn **Mở AirPlay trong Safari** và chọn TV trong Safari. Xem `AIRPLAY_FIX_V4_21_1_VI_EN.md` để biết chi tiết. Tất cả tính năng Full, FFmpeg và Timeshift được giữ nguyên.

## v4.21.1 AirPlay discovery fix (macOS)

Chromecast discovery and AirPlay discovery are separate. The AirPlay section now lists macOS Bonjour video AirPlay receivers. To start playback, open Safari from the app and select the receiver in Safari. All Full Edition features are retained.

---

## Mới trong v4.21 / New in v4.21

**Tiếng Việt**

- **Sửa link M3U đã nhập:** Quản lý nguồn → **Sửa link**. Ứng dụng tải và xác minh danh sách mới trước khi lưu; lỗi sẽ giữ nguyên URL cũ. Giữ nguồn, các kênh khớp, thư mục cá nhân và Yêu thích.
- **Google Cast / Chromecast / Google TV:** Chọn kênh → **Cast / AirPlay** → **Tìm TV** → **Phát trên TV đã chọn**. TV và máy tính phải chung mạng LAN, mDNS không bị chặn. Một số video cần codec/DRM mà TV không hỗ trợ sẽ không phát được.
- **AirPlay (Mac):** Chọn **Mở AirPlay trong Safari**, sau đó chọn AirPlay trong Safari hoặc dùng **Phản chiếu màn hình** trên macOS. Đây không phải cơ chế tự bắt tay AirPlay trong Electron; Windows không có lựa chọn này.
- **TV có trình duyệt:** Chọn **Tạo liên kết xem**, mở địa chỉ LAN trên TV. Liên kết có mã ngẫu nhiên, hết hiệu lực khi dừng truyền hoặc đóng app. Máy phát và TV phải kết nối cùng LAN và tường lửa cho phép.
- **Giữ bản Full:** FFmpeg nhúng, Timeshift, Snapshot 32 luồng, MultiView, Doctor, EPG và cập nhật vẫn có. Không thay Android/iOS.

**English**

- **Edit saved M3U URLs** under Manage Sources → Edit URL. Fetch and validate the replacement first; an error preserves the original source. Matching channel identities, favorites and custom folders are retained.
- **Google Cast:** Select a channel → Cast / AirPlay → Find TVs → Cast. Devices must be on the same LAN with mDNS enabled. DRM, unsupported codecs, authentication and firewall rules may prevent playback.
- **AirPlay on macOS:** Opens the current stream in Safari, where the user chooses an AirPlay destination or macOS Screen Mirroring. This is not automatic native AirPlay pairing in Electron; Windows does not offer Safari AirPlay.
- **Browser on another device:** Generate a temporary signed LAN video page URL and open it on a TV browser. Same-network access required.
- **Full features maintained:** bundled FFmpeg, Timeshift, 32-worker Snapshot, MultiView, Doctor, EPG and the updater. Android/iOS unchanged.

---

> **Open IPTV Pro v4.20 Full / Sửa cập nhật** — FFmpeg được tích hợp vào ứng dụng; giữ nguyên Timeshift 5 phút, Snapshot hàng loạt, kiểm tra 32 luồng, MultiView, Doctor 2.0, EPG, PiP, Failover và cập nhật phiên bản. Giao diện được thu gọn, không cắt chức năng.
> **English:** Full edition bundles FFmpeg and retains every desktop function; only the interface is simplified. macOS and Windows source; Android/iOS unchanged.

> **v4.20 Full (Windows/macOS):** FFmpeg tích hợp trong bộ cài, Timeshift 5 phút và Snapshot 32 luồng đầy đủ. Cập nhật bằng GitHub Releases sẽ tải bộ cài đã xác minh hoặc tự cài khi có chữ ký phù hợp. Mac Apple Silicon và Intel được build riêng để FFmpeg đúng kiến trúc.

# Open IPTV Pro

## 🇻🇳 Tiếng Việt

**Open IPTV Pro** là phần mềm xem và quản lý IPTV mã nguồn mở dành cho **Windows và macOS**. Ứng dụng hỗ trợ 8 ngôn ngữ, danh sách M3U, lịch phát sóng EPG, MultiView 4 kênh, ảnh xem trước, kiểm tra nhiều vòng và sửa link dự phòng.

![Giao diện Open IPTV Pro](docs/images/interface-v4-1.png)

### Tính năng chính

- **Nguồn IPTV:** nhập file hoặc URL M3U, quản lý nhiều nguồn, thu thập M3U công khai, gộp kênh trùng và giữ link dự phòng.
- **Xem truyền hình:** tìm kiếm, thư mục, kéo thả kênh, đồng bộ Yêu thích giữa các màn hình, chế độ cửa sổ nổi PiP khi được hỗ trợ.
- **EPG:** lịch phát sóng XMLTV, ghép kênh, tìm chương trình và nhắc lịch khi ứng dụng đang chạy.
- **MultiView:** xem 4 kênh cùng lúc; rê chuột vào ô nào thì ô đó phát tiếng.
- **Snapshot:** chụp và hiển thị ảnh theo kênh, có thể chạy nhiều tác vụ cùng lúc bằng FFmpeg.
- **Kiểm tra & sửa link:** phân loại Sống / Die / Chưa rõ, kiểm tra nhiều vòng, tự dùng link dự phòng đã xác minh. Hỗ trợ tối đa 32 tác vụ kiểm tra và 32 tác vụ chụp ảnh đồng thời.
- **Timeshift:** lưu bộ đệm 5 phút kể từ khi bật ghi (không thể tua về trước thời điểm bắt đầu lưu nếu nhà cung cấp không hỗ trợ).
- **Cá nhân hóa:** giao diện Sáng / Tối / Tự động, bánh xe chọn màu, hồ sơ riêng và khóa PIN cơ bản.

### Smart IPTV Doctor 2.0 (giữ nguyên)

- **Freeze Detector:** giám sát video chính theo thời gian thực, cảnh báo khung hình đứng hoặc màn hình đen nhưng không vội kết luận link Die. Tùy chọn thử link dự phòng khi đứng hình được xác nhận được **tắt mặc định**.
- **Visual Channel Deduplication:** quét Snapshot đã lưu, đối chiếu dấu vân tay hình ảnh và metadata để đề xuất kênh nghi trùng; **không tự gộp** khi chỉ có một ảnh giống nhau.
- **Doctor 2.0:** điểm ưu tiên đề xuất sửa, phát hiện kênh bị báo Die dù từng phát thành công, thêm dự phòng đã xác minh sau khi bạn chấp thuận, hoàn tác và xuất báo cáo JSON.

![Smart IPTV Doctor 2.0 — ảnh giao diện thử](docs/images/doctor-v4-17.png)

Chi tiết: [Hướng dẫn Doctor 2.0 (Việt/Anh)](docs/DOCTOR_V4_17_VI_EN.md). Phần mới chỉ dành cho Windows/macOS.

### Cập nhật phiên bản tự động (sửa trong v4.20)

Vào **Cài đặt → Cập nhật phiên bản** để kiểm tra GitHub Releases, tải phiên bản mới có tiến độ và xác nhận cài đặt. Mặc định bật **Tự kiểm tra khi mở ứng dụng** và **Tự tải bản mới**, có thể tắt riêng. Nếu bản cài chưa ký hoặc là Portable, app tải bộ cài có checksum SHA256 rồi yêu cầu mở thủ công; không tự thực thi file tải về. Nếu chỉ có mã nguồn hoặc chưa có Release, app hiển thị hướng dẫn rõ ràng.

> **Lần nâng cấp đầu tiên:** v4.15 chưa có trình cập nhật tự tải/cài nên phải **cài v4.16 thủ công một lần**. Để bản Mac tự cài cập nhật về sau, cần ký bằng Apple Developer ID và notarize; bản Windows nên được ký. Xem [Hướng dẫn cập nhật và phát hành](docs/AUTO_UPDATE_VI.md).

### 8 ngôn ngữ giao diện

Vào **Cài đặt → Ngôn ngữ** để chọn: Tiếng Việt, English, Español, Português (Brasil), 简体中文, ไทย, ລາວ hoặc ភាសាខ្មែរ. Thiết lập được lưu sau khi đóng ứng dụng. Tên kênh, tên nhóm M3U và dữ liệu EPG không bị tự động dịch. Một số thông báo kỹ thuật chuyên sâu có thể chưa được dịch hết.

### Sử dụng và cài đặt

1. Mở ứng dụng và chọn **Mở file M3U** hoặc **Thêm URL**.
2. Chọn kênh để phát; có thể đánh dấu Yêu thích và sắp xếp theo thư mục.
3. Vào **Quản lý nguồn** để thu thập, gộp, kiểm tra và sửa link.
4. Vào **Cài đặt** để chọn ngôn ngữ, màu giao diện, số luồng kiểm tra và Snapshot.

**Tạo bộ cài từ mã nguồn:** cần Node.js 22+, npm và Internet cho lần cài gói đầu tiên. Trên Mac chạy `BUILD_MAC.command` (hoặc `npm run dist:mac:arm64` / `npm run dist:mac:x64`); trên Windows chạy `BUILD_WINDOWS.bat` (hoặc `npm run dist:win`). File build nằm trong `dist/`. Bộ cài chưa ký có thể gặp cảnh báo bảo mật; cần ký và notarize trước khi phát hành chính thức.

**Lưu ý pháp lý và quyền riêng tư:** phần mềm không cung cấp kênh trả phí, tài khoản thuê bao hay quyền phát lại nội dung. Chỉ sử dụng luồng bạn có quyền truy cập; không đăng playlist riêng, thông tin đăng nhập hoặc token lên GitHub public. Giấy phép MIT áp dụng cho mã nguồn của ứng dụng, còn FFmpeg, Electron, hls.js và dữ liệu EPG có điều khoản riêng tại [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

Bản **v4.20** chỉ cập nhật phần mềm **Windows/macOS**, không cập nhật Android/iOS. Có thể xem hướng dẫn chi tiết tại [Hướng dẫn tiếng Việt](docs/README_VI.md), [Hướng dẫn build](docs/BUILD.md) và [MIT License](LICENSE).

---

## 🇬🇧 English

**Open-source IPTV desktop player for macOS and Windows, featuring an 8-language interface, M3U playlists, XMLTV program guides, four-channel MultiView, snapshots, and multi-pass stream health checks.**

![Open IPTV Pro desktop interface](docs/images/interface-v4-1.png)

> **v4.20.0 · Desktop only.** Android and iOS source code are intentionally **not** included or updated in this release. The project is licensed under the MIT License; bundled dependencies have their own licenses (see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)). This repository does **not** include commercial television streams, pirated playlists, or viewing rights.

## Visual Stream Diagnostics (retained)

**Smart IPTV Doctor 2.0** adds on-device video freeze/black-screen warnings, local perceptual comparison of saved channel snapshots (review only, no automatic merge), prioritized recommendations and undo for the last change. Recently verified backup URLs can be added after confirmation. These features never treat a static scene or one matching frame as proof a stream is dead or two channels are identical. See [Doctor 2.0 guide (Vietnamese/English)](docs/DOCTOR_V4_17_VI_EN.md).

## In-app updates (v4.16)

**Settings → Software Updates** checks the official GitHub Releases repository, reports available versions, downloads with progress and SHA256 validation, and automatically downloads an available verified update (configurable) and asks permission before installing/restarting. Signed installed desktop builds can update in-app when GitHub Releases includes proper metadata and installers. Unsigned/portable builds download a verified installer for **manual** installation. A source-code-only Release cannot be installed. See [Update instructions (Vietnamese)](docs/AUTO_UPDATE_VI.md).

**Migration:** users of v4.15 must install v4.16 manually once, because the old version does not contain the new updater. macOS automatic installation requires Developer ID signing and notarization; Windows signing is recommended.

## Languages

In **Settings → Language**, choose from:

| Language | Display name | Locale |
| --- | --- | --- |
| Vietnamese | Tiếng Việt | `vi` |
| English | English | `en` |
| Spanish | Español | `es` |
| Portuguese (Brazil) | Português (Brasil) | `pt-BR` |
| Simplified Chinese | 简体中文 | `zh-CN` |
| Thai | ไทย | `th` |
| Lao | ລາວ | `lo` |
| Khmer (Cambodian) | ភាសាខ្មែរ | `km` |

Language changes apply immediately and are saved locally. The application translates navigation, main controls, settings, tooltips, and key workflows; some technical messages may remain in their original wording while translations are being expanded. **Imported channel names, user-created folder names, EPG program names, and source metadata are not machine-translated or modified.** All translation files are available in [`renderer/locales/`](renderer/locales/) and can be improved through pull requests.

![English-language settings screenshot](docs/images/i18n-english-v4-15.png)

## Features

- **Playlist management:** add local M3U files or URLs, refresh sources, import public M3U files from GitHub repositories, merge duplicates, and maintain backup streams.
- **IPTV player:** HLS/MP4 playback, favorites synchronized between screens, channel folders, drag-and-drop channel organization, aspect-ratio controls, and picture-in-picture (where supported).
- **EPG:** XMLTV program guide, mapping options, program search, and reminders while the app is running.
- **MultiView:** watch four channels at once. Hover over a pane to hear its audio; other panes stay muted.
- **Channel snapshots:** preview thumbnails, per-channel capture and bulk capture using bundled FFmpeg.
- **Stream health:** multi-step verification, online/offline/uncertain classification, cautious failover, health history, and Smart IPTV Doctor diagnostics.
- **Performance settings:** independently set up to **32 concurrent URL checks** and **32 snapshot jobs**. For reliability, start with four workers per task.
- **Timeshift:** local five-minute rolling buffer when enabled. The buffer only contains data recorded **since buffering began**, unless the provider supplies DVR/catch-up support.
- **Appearance:** Light, Dark, or automatic system mode; adjustable accent color.
- **Profiles:** separate favorites and basic local parental controls.

### What this app does not promise

Streams may require permissions or provider-specific authentication. A URL can play in a video player yet be inaccessible to automated probes; ambiguous cases are labeled **Unknown**, rather than definitively Offline. EPG coverage and catch-up depend on external sources. Local parental PINs are convenience controls, not operating-system security. Multiview, snapshots, timeshift, and high concurrency may consume significant CPU, RAM, bandwidth and disk space.

## Getting started

1. Download the source ZIP or clone this repository.
2. Import an `.m3u` file using **Open M3U File**, or use **Add URL** to fetch a playlist.
3. Choose a channel to watch. Save channels to Favorites, group them into folders, or open **Manage Sources** for link checks and deduplication.
4. Select **Settings → Language** for another interface language.

**For end users:** install an unsigned `.dmg`/`.exe` built from this repository; builds still need validation on the target operating system. We do not claim to ship signed/notarized installers here.

## Build from source

**Prerequisites:** Git (optional), Node.js 22+ and npm. The provided Mac build script can fetch a verified Node.js copy locally. The Windows build helper may download its build tools. An internet connection is required for the initial `npm install` and build dependencies.

```bash
npm install
npm test
npm run start
```

### macOS

Run `BUILD_MAC.command` from the project directory, or run one of:

```bash
npm run dist:mac:arm64  # Apple Silicon
npm run dist:mac:x64    # Intel
```

The generated `.dmg` is placed in `dist/`. Builds created without a signing identity may be blocked by Gatekeeper; release builds should be signed and notarized.

### Windows

Run `BUILD_WINDOWS.bat`, or install Node.js 22+ and use:

```powershell
npm install
npm test
npm run dist:win
```

Setup and portable `.exe` outputs are placed under `dist/`. Unsigned installers can trigger SmartScreen warnings.

### GitHub Actions

The workflow at `.github/workflows/tao-bo-cai.yml` provides separate Windows x64, macOS Intel and Apple Silicon build jobs. Workflows build source code **without automatically publishing installers**; they upload unsigned artifacts to that workflow run. The repository does not upload your saved IPTV playlists, favorites, EPG, snapshots, or tokens.

## Privacy and data

Application settings and imported playlists are stored on the user's machine. Remote playlist, EPG, streaming and GitHub Release URL requests will contact the respective servers. Do not publish subscription tokens, private playlists, provider credentials, or copyrighted streams in a public Git repository. The **publish to GitHub/Gist** feature has been removed from the app.

## Project structure

```text
renderer/                 Desktop user interface, translations and UI logic
renderer/locales/         Editable JSON translation dictionaries
renderer/i18n.js          Language switching and DOM translation
src/                      Desktop native processes, streaming and FFmpeg integrations
assets/                   Application icons
examples/demo.m3u         Synthetic sample playlist
scripts/                  Platform build helper scripts
tests/                    Node and UI regression tests
docs/                     Additional guides and screenshots
.github/workflows/        CI and installer build jobs
```

## Documentation and contribution

- [Build guide](docs/BUILD.md)
- [Vietnamese guide](docs/README_VI.md)
- [English user guide](docs/USER_GUIDE_EN.md)
- [GitHub repository description](docs/GITHUB_DESCRIPTION_EN.md)
- [Contributing](CONTRIBUTING.md)
- [Security](SECURITY.md)
- [MIT License](LICENSE)

Translations are community-editable. Please preserve placeholders and technical identifiers such as `M3U`, `XMLTV`, `EPG`, `FFmpeg`, `HLS`, and `URL`. Before submitting a translation, run the UI language-switching smoke test and review text clipping on smaller screens.

## Legal notice

Open IPTV Pro is a player and playlist-management application. It does not provide pay-TV accounts, subscriptions or rebroadcasting rights. Use streams only when you have permission to view or redistribute them. This project's MIT license covers the application's own source code only, not the legal status of any third-party streams or EPG data.
