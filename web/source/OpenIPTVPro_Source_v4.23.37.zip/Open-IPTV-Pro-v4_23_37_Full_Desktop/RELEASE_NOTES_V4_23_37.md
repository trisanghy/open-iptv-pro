# Open IPTV Pro 4.23.37

- Volume moved to the upper playback toolbar before Cast/AirPlay.
- Channel-list reopen button reduced to half size, with a narrower gutter.
- Player, EPG and video remain in separate regions with responsive button alignment.
