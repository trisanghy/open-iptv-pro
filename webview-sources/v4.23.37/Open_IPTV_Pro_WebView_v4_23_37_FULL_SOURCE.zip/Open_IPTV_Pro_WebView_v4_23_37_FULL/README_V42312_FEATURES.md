# Open IPTV Pro WebView v4.23.12 — Đồng bộ chức năng từ Electron

**Nguồn tham chiếu:** file người dùng cung cấp `OpenIPTVPro_FULL_v4.23.12_Cinema_Glass_ColorWheel_FIX(1).zip`.
**Đích:** Tauri 2 WebView cho macOS (WKWebView) / Windows (WebView2), không thay Electron ở nhánh `main`.

## Đã đồng bộ

- Giao diện Cinema TV, Glassmorphism, bộ chọn màu Color Wheel, thư viện 11 kiểu UI, cài đặt và icon cập nhật.
- DVR ghi MP4 theo lịch, chọn thư mục lưu bằng native dialog; các RPC quản lý tác vụ ghi hình. Cần FFmpeg đóng gói và stream phù hợp.
- Smart Discovery theo quốc gia, duyệt danh mục nguồn, Doctor 3.0; trình duyệt nguồn GitHub tham chiếu thư mục WebView đúng.
- Nhập EPG từ file XML/XMLTV hoặc GZ bằng trình chọn file native; tìm kiếm EPG.
- Backup `.iptvbackup` (có tùy chọn kèm Snapshot JPG) và Restore xác nhận trước khi thay dữ liệu; hỗ trợ đọc backup JSON của WebView v4.22.
- Các tính năng cũ giữ nguyên: M3U, nhóm, kênh yêu thích, EPG, MultiView, Timeshift, PIP, Cast/AirPlay hỗ trợ, Snapshot, Auto Failover, kiểm tra link, hồ sơ/PIN.
- Tối ưu WebView: xử lý kiểm tra và Snapshot theo đợt tối đa 1.000 kênh, 1–32 worker, hủy tác vụ; khóa quản trị đối với hồ sơ trẻ em; đổi URL nguồn có xác nhận khi số kênh giảm mạnh; đổi tên nhóm không đảo thứ tự.

## Cách build

Mac: mở Terminal trong thư mục dự án đã giải nén, chạy `bash BUILD_MAC.command`; đầu ra DMG tại `~/Downloads/OpenIPTV_WebView_FULL_DMG/`.

Windows: chạy `BUILD_WINDOWS.cmd` tại gốc dự án; đầu ra NSIS tại `%USERPROFILE%\Downloads\OpenIPTV_WebView_FULL_Setup\`. **Không chạy** `electron-original/BUILD_WINDOWS.bat` nếu muốn bản WebView.

Kiểm tra mã nguồn: `npm run test:original`, `npm run test:bridge` hoặc `bash TEST_ALL.command` (cần Node.js). Script build tự chuẩn bị Rust, Node runtime và FFmpeg/FFprobe khi có công cụ, mạng và quyền phù hợp.

GitHub: `bash PUSH_GITHUB_MAC.command` chỉ cập nhật `experiments/webview-full/` và workflow WebView v4.23.12 trên nhánh hiện hữu `experiment/native-webview-ffmpeg`, không force-push, không đụng `main`. **Chưa push trực tiếp** từ môi trường này.

## Kiểm thử và giới hạn

- Kiểm thử mã nguồn: Chromium Electron v4.23.12 148 test đạt / 2 skip theo cấu hình FFmpeg; WebView 47 test đạt sau khi cập nhật bài test tương thích API mới, có test backend RPC thực tế trên localhost.
- Dùng `node --check` để kiểm tra cú pháp toàn bộ JS và Bash syntax check cho script Mac/Git.
- Không thể xác nhận bản DMG/EXE đã build thực tế trên macOS/Windows, cũng chưa thể xác nhận streaming, DVR trên phần cứng, thiết bị Cast/AirPlay, native dialogs trên máy thật. Môi trường thử nghiệm trình duyệt chặn truy cập (ERR_BLOCKED_BY_ADMINISTRATOR).
- LocalStorage của Electron và WebView không tự di chuyển giữa hai origin. Hãy sao lưu trước khi cài mới; không xóa bản cũ hoặc dữ liệu trên máy.
- Tích hợp code tương đương không có nghĩa mọi tính năng hoạt động giống hệt khi dùng engine khác nhau.
