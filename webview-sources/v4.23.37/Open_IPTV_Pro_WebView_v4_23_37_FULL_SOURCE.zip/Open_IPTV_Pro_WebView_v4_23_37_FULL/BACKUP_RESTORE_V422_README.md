# Open IPTV Pro WebView v4.22 — Backup / Restore (Windows + macOS)

## Mở tính năng
Vào **Cài đặt → Sao lưu & Khôi phục dữ liệu**.

- **Sao lưu dữ liệu**: lưu file `Open_IPTV_Pro_Backup_YYYY-MM-DD...iptvbackup.json` bằng hộp thoại hệ điều hành.
- **Khôi phục từ file**: chọn file JSON đúng định dạng, kiểm tra phiên bản/schema và thống kê dữ liệu, xác nhận **ghi đè** rồi ứng dụng tải lại để nhận dữ liệu mới.
- **Kèm bộ nhớ đệm lịch EPG**: bật mặc định; có thể tắt nếu file quá lớn.

## Dữ liệu được sao lưu
Tất cả localStorage keys của chính ứng dụng: danh sách nguồn/playlist, kênh, yêu thích, thư mục, trạng thái nhóm, giao diện, ngôn ngữ, tính năng nâng cao, liên kết dự phòng, hồ sơ và PIN, cấu hình EPG, kiểm tra kênh và Doctor.

**Không bao gồm**: file JPG Snapshot nằm trên ổ đĩa riêng, file media Timeshift hay file cập nhật/installer tải về. Những bản Snapshot có nhúng sẵn vào localStorage vẫn đi theo dữ liệu; liên kết tới file JPG trên máy cũ có thể không tồn tại sau khi chuyển máy.

## An toàn & giới hạn
- File backup JSON **không mã hóa**. Nguồn M3U có thể chứa token; PIN cục bộ cũng nằm trong dữ liệu. Không công khai hoặc chia sẻ file với người không tin cậy.
- Không tự tải lên đám mây, không tự đồng bộ.
- Tối đa **32 MiB**, giới hạn trước khi đọc/ghi; không nhận JSON khác loại, không cho JSON tự ghi các khóa ngoài danh sách được phép.
- Yêu cầu xác nhận ghi đè; kiểm tra toàn bộ file trước khi ghi localStorage. Khi lỗi ghi sẽ cố gắng hoàn tác dữ liệu cũ.
- Khôi phục sẽ thay các khóa thuộc Open IPTV Pro, không xóa localStorage của phần mềm khác.
- Tính năng dùng hộp thoại file native của Tauri 2; không yêu cầu cài plugin.

## Test
- `node --test tests/backup_restore.test.cjs`
- `npm run test:bridge`
- Build macOS với `bash BUILD_MAC.command`; Windows qua `BUILD_WINDOWS.ps1`.

## Lưu ý khi nâng cấp
Hồ sơ trẻ em không được dùng hai nút backup/restore. Ứng dụng ngăn bộ lưu trữ tự động ghi ngược cài đặt cũ trong quá trình tải lại sau khi khôi phục.
