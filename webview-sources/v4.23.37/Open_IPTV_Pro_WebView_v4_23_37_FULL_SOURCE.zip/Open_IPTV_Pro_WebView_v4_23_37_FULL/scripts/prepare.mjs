import {createRequire} from 'node:module';
import {cpSync,copyFileSync,chmodSync,mkdirSync,statSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {execFileSync} from 'node:child_process';
import process from 'node:process';
const require=createRequire(import.meta.url);
console.log('[Assets 1/4] Kiểm tra kiến trúc build...');
const triple={"darwin:arm64":"aarch64-apple-darwin","darwin:x64":"x86_64-apple-darwin","win32:x64":"x86_64-pc-windows-msvc"}[`${process.platform}:${process.arch}`];
if(!triple)throw Error(`Chưa hỗ trợ build: ${process.platform}/${process.arch}. Hãy dùng Mac hoặc Windows đúng kiến trúc cần build.`);
// LAN Cast dependencies are bundled inside backend; no npm required on users' machines.
const castModules=['bonjour-service','castv2-client'];
if(castModules.some(name=>!existsSync(resolve('backend','node_modules',name)))){
 console.log('[Assets 2/4] Cài thư viện LAN Cast cho backend/ (có log npm)');
 execFileSync(process.platform==='win32'?'npm.cmd':'npm',['install','--prefix','backend','--omit=dev','--no-audit','--no-fund','--foreground-scripts','--loglevel=info','--fetch-retries=1','--fetch-timeout=90000'],{stdio:'inherit',timeout:180000});
}
const extension=process.platform==='win32'?'.exe':'';
const folder=resolve('src-tauri','binaries');mkdirSync(folder,{recursive:true});
function bundle(name,src){
 if(!src||!existsSync(src)||statSync(src).size<100000)throw Error(`Thiếu ${name}: ${src}`);
 const dest=join(folder,`${name}-${triple}${extension}`);
 copyFileSync(src,dest);if(process.platform!=='win32')chmodSync(dest,0o755);
 const result=execFileSync(dest,[name==='iptv-node'?'--version':'-version'],{timeout:10000,encoding:'utf8'}).split('\n')[0];
 console.log(`✓ ${name}: ${result} (${(statSync(dest).size/1048576).toFixed(1)} MiB)`);
}
console.log('[Assets 3/4] Kiểm tra FFmpeg và FFprobe đã cài qua npm...');
const ffmpeg=require('ffmpeg-static');
const ffprobe=require('@w6s/ffprobe-static').path;
bundle('ffmpeg',ffmpeg);bundle('ffprobe',ffprobe);
// Node is kept INSIDE the installer to run the existing Node backend, NOT a user's prerequisite.
const {downloadNodeBinary}=await import('./prepare-node.mjs');
console.log(`[Assets 4/4] Chuẩn bị Node runtime ${process.version}: dùng cache nếu có, nếu chưa có sẽ tải từ nodejs.org...`);
const portableNode=await downloadNodeBinary();
bundle('iptv-node',portableNode);
const license=join(portableNode.replace(/[/\\]node(?:\.exe)?$/,''),'NODE_LICENSE.txt');
if(existsSync(license)){mkdirSync(resolve('third_party'),{recursive:true});copyFileSync(license,resolve('third_party','NODE_LICENSE.txt'));}
let hls=resolve('node_modules','hls.js','dist','hls.min.js');
copyFileSync(hls,resolve('frontend','hls.min.js'));
const dash=resolve('node_modules','dashjs','dist','modern','umd','dash.all.min.js');
if(!existsSync(dash))throw Error('Thiếu Dash.js nội bộ: '+dash);
copyFileSync(dash,resolve('frontend','dash.all.min.js')); 
console.log('✓ hls.js offline, all original renderer code and FFmpeg/FFprobe kept.');
