#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo 'Thiếu Node.js. Cài Node.js 22 LTS trước khi kiểm tra.'; exit 1; }
echo '=== Kiểm tra cú pháp JavaScript ==='
for file in frontend/*.js backend/*.cjs; do node --check "$file"; done
echo '=== Test Chromium + WebView + Backend HTTP ==='
npm test
echo '=== Kiểm tra script Mac / Git ==='
bash -n BUILD_MAC.command PUSH_GITHUB_MAC.command
echo 'ĐÃ KIỂM TRA XONG MÃ NGUỒN (chưa build DMG/EXE native).'
