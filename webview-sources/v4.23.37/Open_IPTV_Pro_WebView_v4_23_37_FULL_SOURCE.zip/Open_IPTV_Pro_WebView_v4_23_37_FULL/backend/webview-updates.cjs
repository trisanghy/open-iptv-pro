'use strict';
const {checkUpdate}=require('./update-check.cjs');
// GitHub may publish Electron and Tauri artifacts in the same repo. Only match
// real WebView installer files for the target platform, NEVER an Electron setup.
function isolateWebView(release){
 if(!release || typeof release!=='object')return release;
 return {...release,assets:(Array.isArray(release.assets)?release.assets:[]).filter(a=>
   typeof a.name==='string' && (/webview/i.test(a.name) && /\.(?:dmg|exe)$/i.test(a.name)
     || /^SHA256SUMS\.txt$/i.test(a.name)))};
}
async function checkWebViewRelease(repo,version,fetcher=fetch,platform=process.platform,arch=process.arch){
 const filteredFetch=async (...args)=>{
  const response=await fetcher(...args);
  // /releases/latest and /releases?per_page=N are the only response bodies to filter.
  if(!response.ok || !/\/releases(?:\/latest|\?)/.test(String(args[0])))return response;
  return {ok:response.ok,status:response.status,url:response.url,json:async()=>{
    const data=await response.json();
    return Array.isArray(data)?data.map(isolateWebView):isolateWebView(data);
  }};
 };
 const result=await checkUpdate(repo,version,filteredFetch,platform,arch);
 if(!result.noRelease&&!result.newer&&!result.sourceOnly)return result;
 // The latest generic Release can be Electron-only; report no WebView release.
 if(result.sourceOnly)return {...result,newer:false,noRelease:true,assets:[],latest:null};
 return result;
}
module.exports={checkWebViewRelease,isolateWebView};
