# Open IPTV Pro Windows — bản sửa lỗi build 10/11/2026

## Hai lỗi trong ảnh gửi

1. `Cannot find package.json in ...\scripts` — electron-builder đang chạy sai project. Script Electron đã được neo vào thư mục `electron-original` chứa `package.json` và truyền `--projectDir` tường minh.
2. `Cannot create symbolic link ...\winCodeSign ... A required privilege is not held by the client` — winCodeSign giải nén symlink trên Windows thiếu quyền. Với **bản build Electron không ký số để chạy thử**, script dùng `--config.win.signAndEditExecutable=false`, tránh chỉnh resource/đường mã ký gây lỗi symlink. Lưu ý: icon/metadata của file `.exe` có thể không được nhúng theo cách này. Để build release giữ nguyên icon/chữ ký cần bật Windows Developer Mode hoặc chạy môi trường có quyền symbolic link và sử dụng script phát hành bình thường.

## Nên build đúng bản WebView

Trong thư mục đã giải nén, nhấp **BUILD_WINDOWS.cmd**. Script sẽ gọi `BUILD_WINDOWS.ps1` sử dụng **Tauri 2/WebView2**, kiểm tra Node, Rust/MSVC, chạy test, chuẩn bị FFmpeg/FFprobe, tạo bộ cài Windows tại `Downloads\OpenIPTV_WebView_FULL_Setup`.

`BUILD_WINDOWS.cmd` không chạy `electron-builder`, do đó không gặp lỗi `winCodeSign` của ảnh.

## Nếu muốn build cả bản Chromium/Electron

Nhấp `electron-original\BUILD_WINDOWS.bat`, sử dụng script Electron đã sửa. Bộ cài ở `electron-original\dist`.

## Nếu build từ bản GitHub nhánh experiment/native-webview-ffmpeg

Nên vào `experiments\webview-full` sau khi đã push gói WebView mới, chạy `BUILD_WINDOWS.cmd` **trong thư mục đó**, không chạy `BUILD_WINDOWS.bat` tại gốc repo (đó là bản Chromium/Electron).

Nếu bước Tauri báo thiếu MSVC: cài Microsoft Visual Studio Build Tools với workload **Desktop development with C++**. Windows 10/11 cần WebView2 runtime khi chạy app. Cần Node LTS (ưu tiên 22) và Rust MSVC cho máy build. Không gỡ hay xóa bản đã cài trước đó.

## Giới hạn xác minh

Đã kiểm tra cấu trúc source và chạy các bài unit test bằng Node trong môi trường Linux. Không có Windows ở đây để xác nhận EXE thực tế hay mã ký số.
