# Open IPTV Pro v4.23.35 — một lệnh build macOS

Trên máy chưa có source, tải một file `BUILD_OPEN_IPTV_PRO_MAC.command` được cung cấp cùng phát hành này.
Mở Terminal và nhập: `bash ~/Downloads/BUILD_OPEN_IPTV_PRO_MAC.command`.

Script tự chứa mã nguồn đúng v4.23.35, tự cài Node nếu cần, cài thư viện, chạy toàn bộ kiểm thử, build DMG đúng kiến trúc Mac, rồi chỉ giữ lại 2 file ở `~/Downloads/OpenIPTVPro_Build_v4.23.35`:

- `Open-IPTV-Pro-4.23.35-mac-arm64.dmg` hoặc `Open-IPTV-Pro-4.23.35-mac-x64.dmg`
- `OpenIPTVPro_Source_v4.23.35.zip`

Không xoá các bản cài khác, dữ liệu ứng dụng hoặc thư mục Downloads ngoài thư mục làm việc tạm do script tạo. Nếu build lỗi, báo cáo ở `~/Downloads/OpenIPTVPro_Build_v4.23.35_ERROR.log`.

Lưu ý: đây là build developer chưa có chứng chỉ ký của Apple; macOS có thể yêu cầu xác nhận mở ứng dụng.
