# WebView v4.22 Full – kết quả kiểm thử

Nguồn: so sánh hai ZIP người dùng cung cấp, đồng bộ Electron/Chromium v4.22.0 vào Tauri 2 WebView.

- **82/82** bài test mã nguồn Chromium/Electron v4.22 (`npm run test:original`) – ĐẠT.
- **25/25** bài test bridge/backend WebView (`npm run test:bridge`) – ĐẠT. Trong đó có test backend RPC thực, JPEG FFmpeg thực, proxy, Cast relay LAN mô phỏng và 5 bài regression mới cho nâng cấp v4.22.
- Kiểm tra cú pháp Node tất cả file JS/CJS, định dạng JSON và TOML, đối chiếu tài nguyên HTML: ĐẠT.
- **Chưa chạy** Tauri build native trên macOS hoặc Windows trong môi trường này (không có Rust/macOS SDK và Windows MSVC).
- **Chưa xác nhận** DMG/EXE hoạt động, video codec DRM, TV Cast, AirPlay trên máy thật.
- GUI smoke thử với Chromium headless nhưng bị chính sách môi trường từ chối tải cả `file://` và `http://127.0.0.1` (`ERR_BLOCKED_BY_ADMINISTRATOR`); không tính là bài test đạt.

Để build và kiểm thử trên Mac, mở Terminal trong thư mục này rồi chạy `bash BUILD_MAC.command`; trên Windows mở PowerShell chạy `./BUILD_WINDOWS.ps1` (Windows PowerShell cho phép script).
