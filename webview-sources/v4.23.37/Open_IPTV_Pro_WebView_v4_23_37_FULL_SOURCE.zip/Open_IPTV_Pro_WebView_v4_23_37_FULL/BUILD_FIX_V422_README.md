# Khắc phục dừng tại “Cài thư viện build” (macOS / Windows)

## Nguyên nhân đã xác định trong mã nguồn

`npm install` chạy npm lifecycle script `prepare` ngầm. Bản trước đặt `prepare: node scripts/prepare.mjs`, nên chỉ cài thư viện đã kéo thêm Node runtime, binary và dependencies backend (có các tải mạng chưa có dòng trạng thái). `npm run prepare` và Tauri `beforeBuildCommand` còn gọi lại bước này. Điều đó khiến màn hình dừng ở “Cài thư viện build” mà không có thông tin. Tình trạng mạng thực tế trên máy chưa được xác minh qua ảnh.

## Đã sửa

- Đổi npm lifecycle `prepare` thành `assets`: không tự tải nhiều tài nguyên ngầm khi `npm install`.
- Chỉ chạy `npm run assets` một lần trong build, bỏ bước Tauri `beforeBuildCommand` trùng lặp. `npm run build` và `npm run dev` tự chuẩn bị assets.
- `npm install --foreground-scripts --loglevel=info`: in tiến trình install, giới hạn thời gian chờ mạng npm mỗi request và retry 1 lần.
- Từng bước assets đều có log, có log về lượt tải Node runtime (cache khi có).
- Ghi lỗi build về `~/Downloads/OpenIPTV_WebView_FULL_build.log`.
- Vẫn giữ UI/Backend/Backup & Restore; không đụng đến dữ liệu người dùng.

## Chạy trên macOS

1. Dừng build cũ: bấm Ctrl+C trong Terminal cũ.
2. Đặt ZIP sửa lỗi trong `~/Downloads`.
3. Chạy:

```bash
mkdir -p ~/Downloads/OpenIPTV_WebView_v422_BuildFix && \
unzip -oq ~/Downloads/Open_IPTV_Pro_WebView_v4_22_0_Backup_Restore_BUILD_FIX.zip -d ~/Downloads/OpenIPTV_WebView_v422_BuildFix && \
cd ~/Downloads/OpenIPTV_WebView_v422_BuildFix/Open_IPTV_Pro_WebView_v4_22_0_FULL_UPDATE && \
bash BUILD_MAC.command
```

File DMG: `~/Downloads/OpenIPTV_WebView_FULL_DMG/`. Khi báo lỗi, gửi 60 dòng cuối:

```bash
tail -n 60 ~/Downloads/OpenIPTV_WebView_FULL_build.log
```

## Chú ý

Lần build đầu vẫn cần Internet để tải npm, FFmpeg/Node và Rust crates. Ảnh màn hình không đủ để kết luận hỏng mạng hoặc tiến trình chết; nếu npm đang tải thì có thể mất vài phút. Chưa thử biên dịch DMG/EXE trên máy macOS/Windows thực.
