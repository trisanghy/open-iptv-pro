#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/Downloads"
LOG="$HOME/Downloads/OpenIPTV_WebView_FULL_build.log"
exec > >(tee -a "$LOG") 2>&1
trap 'code=$?; if (( code != 0 )); then echo "BUILD THẤT BẠI (mã $code). Xem log: $LOG"; fi' EXIT
printf '\n=== Open IPTV Pro v4.23.37 WebView / Backup & Restore / Build Fix ===\n'
printf 'Thư mục nguồn: %s\nLog: %s\n' "$PWD" "$LOG"
FREE_KB=$(df -Pk . | awk 'NR==2 {print $4}')
if (( FREE_KB < 10*1024*1024 )); then
  echo "Cần tối thiểu 10GB dung lượng trống để build. Hiện có $((FREE_KB/1024)) MB."
  echo 'Không tự xóa dữ liệu hoặc cache người dùng.'; exit 1
fi
if ! xcode-select -p >/dev/null 2>&1; then
  echo 'Thiếu Xcode Command Line Tools. Đang mở cửa sổ cài đặt của Apple...'; xcode-select --install || true
  echo 'Cài Xcode Command Line Tools xong rồi chạy lại file này.'; exit 1
fi
if ! command -v node >/dev/null; then
 if command -v brew >/dev/null; then
  echo 'Tự cài Node.js cho công đoạn build...'; brew install node
 else
  echo 'Chưa có Node.js. Cài Node.js LTS từ https://nodejs.org hoặc Homebrew rồi chạy lại.'; exit 1
 fi
fi
if ! command -v cargo >/dev/null; then
 echo 'Cài Rust profile tối thiểu (không tải rust-src và docs)...'
 curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs | sh -s -- -y --profile minimal
fi
export PATH="$HOME/.cargo/bin:$PATH"
if ! command -v cargo >/dev/null; then echo 'Không tìm thấy cargo sau cài đặt';exit 1;fi
printf '\n== Cài thư viện build ==\n'
echo 'Đang tải các gói npm. Các bước cài đặt (kể cả postinstall) sẽ hiện trực tiếp.'
echo 'Nếu mạng có vấn đề, npm sẽ báo lỗi/timeout thay vì im lặng lâu.'
export npm_config_fetch_retries=1
export npm_config_fetch_timeout=90000
export npm_config_fetch_retry_mintimeout=10000
export npm_config_fetch_retry_maxtimeout=30000
npm install --no-audit --no-fund --foreground-scripts --loglevel=info
printf '\n== Kiểm thử mã v4.23.37 gốc và bridge ==\n'
npm run test:original
npm run test:bridge
printf '\n== Đóng gói tài nguyên FFmpeg/FFprobe/Node (có trạng thái) ==\n'
npm run assets
printf '\n== Build ứng dụng Tauri & tạo DMG ==\n'
npx --no-install tauri build --bundles dmg
mkdir -p "$HOME/Downloads/OpenIPTV_WebView_FULL_DMG"
find src-tauri/target -type f -path '*/bundle/dmg/*.dmg' -exec cp -f '{}' "$HOME/Downloads/OpenIPTV_WebView_FULL_DMG/" \;
if ! find "$HOME/Downloads/OpenIPTV_WebView_FULL_DMG" -maxdepth 1 -name '*.dmg' | grep -q .; then
 echo 'Build chưa tạo ra DMG; xem log tại Downloads.';exit 1
fi
echo 'THÀNH CÔNG: DMG tại ~/Downloads/OpenIPTV_WebView_FULL_DMG/'
open "$HOME/Downloads/OpenIPTV_WebView_FULL_DMG" || true
