# Cập nhật GitHub – đúng nhánh WebView thử nghiệm

**Đích duy nhất:** `trisanghy/open-iptv-pro` → `experiment/native-webview-ffmpeg`.

- Ghi bản WebView v4.22.0 có Backup/Restore + Build Fix vào `experiments/webview-full/`.
- Cập nhật workflow `.github/workflows/build-native-webview-v422.yml` (đã sửa `npm run prepare` thành `npm run assets`).
- Không sửa `main`, không force push, không chạm các file Chromium ở gốc repo.
- Clone nhánh từ xa vào một thư mục mới trong Downloads trước khi commit để tránh đụng repo hiện tại.
- Giữ các file cũ khác ngoài danh sách mã nguồn đã cung cấp; **không xóa tự động** file ngoài gói trong `experiments/webview-full/`.
- Yêu cầu Git và quyền ghi GitHub với repo; GitHub CLI (`gh`) là tùy chọn. Nếu đang đăng nhập sai tài khoản bằng `gh`, script sẽ dừng, không push.
- Workflow CI có thể cần sửa thêm nếu macOS/Windows runner gặp vấn đề về môi trường build; kiểm thử mã nguồn không chứng minh DMG/EXE được tạo thành công.

## Lệnh thực hiện trên Mac

Đặt ZIP vào thư mục Downloads rồi chạy:

```bash
cd ~/Downloads && \
unzip -oq Open_IPTV_Pro_WebView_v4_22_0_Backup_Restore_GitBranch_FIX.zip && \
bash Open_IPTV_Pro_WebView_v4_22_0_FULL_UPDATE/PUSH_GITHUB_MAC.command
```

Không đòi hỏi build DMG trước khi push mã nguồn. Nếu GitHub yêu cầu đăng nhập, có thể dùng `gh auth login` rồi chạy lại.
