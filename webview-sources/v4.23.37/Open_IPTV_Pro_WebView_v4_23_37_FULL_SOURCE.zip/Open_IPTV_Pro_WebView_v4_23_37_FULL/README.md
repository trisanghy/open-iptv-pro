# Open IPTV Pro v4.23.37 — Native WebView (Tauri 2)

Đồng bộ từ file Electron `OpenIPTVPro_Source_v4.23.35.zip` do người dùng cung cấp, dựa trên WebView v4.23.12.

## Chức năng cập nhật

- Thanh điều khiển video 2 hàng; EPG hiện tại/tiếp theo, Cast, AirPlay, PiP, toàn màn hình, tỉ lệ khung hình, link thủ công.
- Thu gọn sidebar và danh sách kênh độc lập; kéo thả kênh (đơn/nhiều), chuyển thư mục và đổi thứ tự nhóm bằng Pointer Events trên macOS/Windows; hỗ trợ Shift chọn nhiều kênh.
- Chế độ phát HLS/DASH và FFmpeg dự phòng qua backend localhost và file segment HLS tạm có kiểm tra tên file.
- Bộ 11 giao diện, Cinema/Glass, màu tùy chỉnh, trạng thái người dùng giữa các lần mở.
- Giữ Backup/Restore, kiểm tra/Snapshot theo lô 1.000 kênh, DVR, Timeshift, Doctor 3.0 và Smart Discovery.

## Build

Mac: `bash BUILD_MAC.command` (DMG). Windows: `BUILD_WINDOWS.cmd` (NSIS). Script sẽ chuẩn bị Node/FFmpeg, HLS và DASH từ npm; cần Rust và bộ công cụ native tương ứng.

## Kiểm chứng và giới hạn

Kiểm thử tự động mã nguồn mới và bridge trước khi phát hành. Chưa xác minh gói DMG/EXE cài đặt chạy thực tế, AirPlay/Cast, nguồn IPTV thực và DRM ở đây. WKWebView/WebView2 có khác biệt codec và network với Chromium Electron, nên không cam kết phát giống hệt. Bản sửa kéo thả được phân phối từ GitHub bằng bản vá có kiểm tra SHA-256.
