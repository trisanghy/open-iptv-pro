"""Optional browser-only smoke: backup dialog cancel and folder ordering."""
from playwright.sync_api import sync_playwright
from ui_runtime_smoke import load,PLAYLIST
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1360,'height':900});errors=load(page)
 page.evaluate('playlist=>window.IPTVState.importSource("Demo","demo.m3u",playlist,"file")',PLAYLIST)
 page.locator('[data-page="folders"]').click()
 page.locator('.folder-card .folder-rename').first.click()
 page.locator('#folderRename').fill('Đã đổi tên nhóm')
 page.locator('#modalConfirm').click()
 groups=page.evaluate('window.IPTVState.getStore().groupOrder')
 assert groups[0]=='Đã đổi tên nhóm',groups
 page.locator('[data-page="settings"]').click()
 page.evaluate('''() => {const file=JSON.parse(window.OpenIPTVBackup.create(localStorage,{includeEPG:false}).content);file.storage['open-iptv-pro-4']='{"sources":[],"channels":[],"folders":[]}';window.__importText=JSON.stringify(file);window.streamleaf={readBackupFile:async()=>window.__importText};}''')
 before=page.evaluate('localStorage.getItem("open-iptv-pro-4")')
 page.locator('#backupImportBtn').click()
 page.wait_for_selector('.backup-confirm-overlay')
 assert page.locator('.backup-confirm-overlay').is_visible()
 assert page.evaluate('localStorage.getItem("open-iptv-pro-4")')==before
 page.locator('.backup-confirm-box button').first.click()
 assert not page.locator('.backup-confirm-overlay').count()
 assert page.evaluate('localStorage.getItem("open-iptv-pro-4")')==before
 assert not errors,errors
 print('BACKUP CANCEL + FOLDER ORDER: PASSED')
 b.close()
