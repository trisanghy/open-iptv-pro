"""Optional browser simulation: 2050-channel batch checking through mocked Tauri APIs."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
from ui_runtime_smoke import BASE, HTML, SCRIPTS
M=2050
MOCK='''
window.__batchStarts=[];
window.streamleaf={
 capabilities:async()=>({native:true,platform:'darwin',ffmpegExists:true,snapshotBase:'http://127.0.0.1/snapshot?file='}),
 batchStart:async(kind,items,workers)=>{const id=window.__batchStarts.length;window.__batchStarts.push({kind,items,workers});return {id,total:items.length,workers};},
 batchStatus:async(id,offset)=>{const entries=window.__batchStarts[id].items;const results=entries.slice(offset,offset+250).map((item,i)=>({index:i+offset,ok:true,value:{status:'alive',positiveEvidence:true,reason:'mock-verified'}}));return {results,nextOffset:offset+results.length,done:entries.length,total:entries.length,finished:true};},
 batchCancel:async()=>true,check:async()=>({status:'alive'}),onUpdateStatus:()=>{},updateStatus:async()=>({phase:'idle'}),openM3U:async()=>null
};
'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1360,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('about:blank')
 page.evaluate('''() => {let map=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)}})}''')
 page.set_content(HTML);page.add_style_tag(content=(BASE/'styles.css').read_text())
 for f in SCRIPTS:
  if f=='hls.min.js':page.add_script_tag(content='window.Hls=class {static isSupported(){return false}};')
  else:
   if f=='app.js':page.add_script_tag(content=MOCK)
   page.add_script_tag(content=(BASE/f).read_text())
 page.evaluate('''n => {const chunks=['#EXTM3U'];for(let i=0;i<n;i++)chunks.push(`#EXTINF:-1 group-title="All",TV ${i}`,`https://example.com/tv${i}.mp4`);window.IPTVState.importSource('batch','https://example.com/list.m3u',chunks.join('\\n'),'file');}''',M)
 page.locator('[data-page="sources"]').click()
 page.locator('#sourceCheckAllBtn').click()
 page.wait_for_function('window.__batchStarts.length===3 && window.IPTVState.getStore().channels.every(c=>c.status==="alive")',timeout=25000)
 out=page.evaluate('''()=>({counts:window.__batchStarts.map(x=>x.items.length),statuses:window.IPTVState.getStore().channels.filter(x=>x.status==='alive').length})''')
 assert out=={'counts':[1000,1000,50],'statuses':2050},out
 assert not errors,errors
 print('NATIVE MOCK 2050 BATCH: PASSED',out)
 b.close()
