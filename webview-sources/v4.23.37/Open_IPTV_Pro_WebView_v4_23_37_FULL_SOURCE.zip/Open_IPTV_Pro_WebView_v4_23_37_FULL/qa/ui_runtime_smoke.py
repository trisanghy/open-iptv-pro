"""Optional UI smoke test with system Chromium and python playwright.
Usage: python qa/ui_runtime_smoke.py
Runs from about:blank to be usable without external networking; this is a
renderer smoke test, not a native Tauri or real stream playback test.
"""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

BASE=Path(__file__).resolve().parents[1]/'frontend'
HTML=(BASE/'index.html').read_text()
SCRIPTS=re.findall(r'<script\s+src="([^"]+)"\s*>\s*</script>',HTML)
HTML=re.sub(r'<script\s+src="[^"]+"\s*>\s*</script>','',HTML)
HTML=re.sub(r'<meta\s+http-equiv="Content-Security-Policy"[^>]*>','',HTML)
HTML=re.sub(r'<link\s+rel="stylesheet"[^>]*>','',HTML)
PLAYLIST='#EXTM3U\n#EXTINF:-1 group-title="Tin tức" tvg-id="v1",Kênh 1\nhttps://example.com/test1.mp4\n#EXTINF:-1 group-title="Thể thao",Kênh 2\nhttps://example.com/test2.mp4\n#EXTINF:-1 group-title="Giải trí",Kênh 3\nhttps://example.com/test3.mp4\n'

def load(page,seed=None):
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('about:blank')
    page.evaluate('''seed => {let m=new Map(Object.entries(seed));Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),get length(){return m.size},key:i=>[...m.keys()][i]}});}''',seed or {})
    page.set_content(HTML)
    page.add_style_tag(content=(BASE/'styles.css').read_text())
    for f in SCRIPTS:
        if f=='hls.min.js':page.add_script_tag(content='window.Hls=class {static isSupported(){return false}};')
        else:page.add_script_tag(content=(BASE/f).read_text())
    page.wait_for_timeout(150)
    assert not errors, errors
    return errors

def test_all(browser):
    page=browser.new_page(viewport={'width':1360,'height':850})
    errors=load(page)
    assert page.locator('.active-page').count()==1
    assert page.evaluate('window.IPTVState && !window.streamleaf')
    count=page.evaluate('playlist => {window.IPTVState.importSource("Thử nghiệm","demo.m3u",playlist,"file");return window.IPTVState.getStore().channels.length}',PLAYLIST)
    assert count==3,count
    assert page.locator('#channelList .channel-item').count()==3
    page.locator('.channel-item .channel-star').first.click()
    assert len(page.evaluate('window.IPTVState.getStore().favoriteKeys'))==1
    page.locator('[data-page="fav"]').click()
    assert page.locator('#favoriteList .fav-card').count()==1
    page.locator('[data-page="settings"]').click()
    assert page.locator('#backupExportBtn').is_visible()
    assert page.evaluate("window.OpenIPTVBackup.create(localStorage,{includeEPG:false}).summary.channels") == 3
    # Spacebar inside form controls must not start/stop playback or become prevented.
    result=page.evaluate('''() => {let e=new KeyboardEvent('keydown',{key:' ',bubbles:true,cancelable:true});let t=document.querySelector('#backupURLs');t.dispatchEvent(e);return e.defaultPrevented;}''')
    assert result is False, 'Space in textarea incorrectly swallowed'
    page.locator('[data-page="multiview"]').click()
    before=page.locator('#multiTile0 video').evaluate('(e)=>{window.__videoProbe=e;return e.isConnected}')
    assert before
    page.locator('[data-page="multiview"]').click()
    assert page.locator('#multiTile0 video').evaluate('(e)=>e===window.__videoProbe'),'Repeated multiview nav rebuilt video'
    # All pages instantiate without unhandled errors.
    for name in ['tv','fav','epg','multiview','shots','folders','sources','health','doctor','profiles','settings']:
        page.locator('[data-page="'+name+'"]').first.click()
    assert not errors,errors
    for width in [980,1100,1360]:
        page.set_viewport_size({'width':width,'height':850})
        page.locator('[data-page="tv"]').click()
        metrics=page.evaluate('''() => ({body:document.body.scrollWidth, window:innerWidth, panel:document.querySelector('.player-control-card').scrollWidth, control:document.querySelector('.player-control-card').clientWidth})''')
        print('width',width,metrics)
        assert metrics['body']<=metrics['window']+2, 'Main app horizontal overflow'
    page.close()
    child={'open-iptv-pro-advanced-v1':'{"profiles":[{"id":"parent","name":"Parent","child":false},{"id":"kid","name":"Kid","child":true}],"profileId":"kid","pin":{"salt":"hello","hash":"x"}}'}
    page=browser.new_page(viewport={'width':1360,'height':850});errors=load(page,child)
    assert page.locator('#urlBtn').is_disabled()
    rejected=page.evaluate('''playlist => {try{window.IPTVState.importSource('s','s.m3u',playlist,'file');return false;}catch{return true;}}''',PLAYLIST)
    assert rejected,'Child bypassed addSource'
    assert page.evaluate('window.IPTVState.getStore().channels.length')==0
    assert not errors,errors
    page.close()

if __name__=='__main__':
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        test_all(browser)
        browser.close()
    print('UI RUNTIME SMOKE: PASSED')
