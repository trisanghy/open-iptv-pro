# Đồng bộ WebView 4.22 từ Chromium/Electron 4.22

**Đầu vào:** hai gói ZIP do người dùng cung cấp. `electron-original/` được thay bằng trọn bộ mã nguồn v4.22 để dễ kiểm toán.

- [x] WebView source + Tauri config + Node compatibility: phiên bản 4.22.0.
- [x] Đồng bộ bộ icon SVG và CSS mới của v4.22.
- [x] Đồng bộ thiết kế UI cập nhật bản phát hành (publisher cố định, tiến độ, thông báo).
- [x] Đồng bộ phân tích GitHub release/tag và chọn OS/arch, giới hạn **chỉ** file WebView; chống tải nhầm installer Electron.
- [x] Giữ FFmpeg/FFprobe, 1–32 worker, proxy, Timeshift, Snapshot, Cast/AirPlay, M3U editing, EPG, MultiView, PiP, Doctor, i18n.
- [x] Không bổ sung mobile iOS/Android, không push GitHub.
- [ ] Build DMG trên macOS và Setup EXE Windows thực; kiểm thử GUI, Cast/AirPlay thực.
- [ ] Auto-install Tauri ký số chưa có; phát hành bộ cài WebView cần kèm SHA256/digest.

WebView sử dụng WKWebView/macOS và WebView2/Windows, **không phải** phiên bản Chromium được đóng gói riêng của Electron.
