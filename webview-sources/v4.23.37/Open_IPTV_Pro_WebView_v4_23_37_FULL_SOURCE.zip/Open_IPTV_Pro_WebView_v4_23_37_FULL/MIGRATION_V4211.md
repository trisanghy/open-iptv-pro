# Các khác biệt chính so với nhánh WebView v4.19

| Hạng mục | Nguồn Electron v4.21.1 | Tình trạng WebView v4.21.1 |
|---|---|---|
| URL playlist | source-edit.js, app.js | Đã tích hợp; xác nhận giảm >50% bằng checkbox |
| Google Cast | cast-service.cjs, cast-relay.cjs, cast-ui.js | Đã port, backend Node giữ relay/token, bundle bonjour-service+castv2-client |
| AirPlay | airplay-discovery.cjs, Safari | Đã port quét Bonjour; Safari chọn thiết bị |
| FFmpeg + FFprobe | FFmpeg Full | Sidecar giữ nguyên, không cắt codec hay Timeshift |
| Snapshot | FFmpeg direct | Bảo lưu fallback proxy và lô 32 tác vụ nhanh |
| Quét 32 luồng | Electron IPC | Bảo lưu batch worker ở backend Node |
| Collector merge | Collector v4.21.1 | Giữ logic cũ và modal xác nhận trong WebView |
| Auto update | Electron updater | Kiểm tra/tải có checksum, cài thủ công WebView |
| WebView DRM/codec | Chromium/Electron | Phụ thuộc WKWebView/WebView2, chưa chứng minh tương đương |

Test chạy tại Linux: 76 test gốc + 20 test WebView đạt. Không có DMG/EXE đã biên dịch.
