# Open IPTV Pro WebView v4.22.0 — FULL AUDITED / 09-11-2026

## Phạm vi & kết quả

Bản sửa từ **Open_IPTV_Pro_WebView_v4_22_0_Backup_Restore_GitBranch_FIX.zip** do người dùng cung cấp. Giữ nguyên bản **Chromium/Electron** trong `electron-original/`, không thay thế engine WKWebView (macOS) hoặc WebView2 (Windows). Không cập nhật các bản iOS/Android.

Kiểm tra thực tế thực hiện trong phiên:
- 82/82 bài kiểm thử Chromium gốc đạt (`npm run test:original`).
- 39/39 bài kiểm thử WebView đạt (`npm run test:bridge`), gồm thêm bốn hồi quy mới và một bài kiểm thử backend HTTP tích hợp: RPC xác thực, tải playlist, HLS rewrite, HTTP Range và từ chối request khác origin.
- UI smoke trong Chromium headless, với HTML/CSS/JS của WebView được nạp trong môi trường cách ly (không phụ thuộc web): 11 trang, nhập M3U, yêu thích, đổi trang, Multiview, cấu hình, hồ sơ trẻ em, phím Space trong ô nhập, kích thước 980/1100/1360 px.
- Mô phỏng RPC native với 2.050 kênh qua ba đợt 1000 + 1000 + 50, không bỏ sót.
- UI smoke lưu/hủy backup và giữ thứ tự thư mục khi đổi tên.
- Xác nhận cú pháp JS qua `node --check`; cú pháp Bash qua `bash -n`.

## Lỗi xác định đã sửa

1. **Lỗi logic hotkey**: phím Space trước đây kích hoạt phát/dừng khi đang gõ ở textarea, button hoặc modal. Đã chặn khi người dùng tương tác với form/dialog và tổ hợp modifier.
2. **Môi trường UI**: trang frontend trong trình duyệt không có Tauri vẫn bị đánh dấu native và gọi API lỗi. Chỉ tạo bridge khi có API Tauri thật; khởi tạo lại handshake khi backend chưa sẵn sàng lần đầu.
3. **Hồ sơ trẻ em**: các callback thêm/đổi tên/xóa nguồn, kiểm tra hàng loạt, Snapshot hàng loạt và xuất playlist trước đây có thể thiếu kiểm tra quyền sâu bên trong. Đã kiểm tra thêm tại điểm thực thi.
4. **MultiView**: bấm lại tab MultiView có thể tạo lại `<video>` đang phát, bỏ rơi video cũ. Chỉ tái dựng khi thực sự vào trang từ tab khác.
5. **Tác vụ lớn**: ứng dụng có thể chuyển quá nhiều hơn backend cho phép trong một batch và thất bại sau khi đã bắt đầu. Đã chia 1000 kênh / đợt; giữ 1–32 workers, hỗ trợ hủy; kiểm tra 2050 kênh bằng mock.
6. **Lỗi promise**: một số lỗi tác vụ native không được xử lý triệt để, gây unhandled promise rejection ở sự kiện. Đã thông báo lỗi trên giao diện và hoàn tất cleanup.
7. **Khôi phục backup**: thêm xác nhận trong giao diện có thể thao tác bằng bàn phím (không lệ thuộc `window.confirm()`), xác minh kỹ kiểu dữ liệu con khi nhập file, không sửa dữ liệu trước khi xác nhận; giữ rollback cũ khi ghi thất bại.
8. **Playlist M3U**: dấu phẩy bên trong giá trị đặt trong dấu ngoặc kép (vd. `group-title="News, Sports"`) từng làm tách sai tên kênh; backend và renderer hiện parse thống nhất.
9. **Thư mục**: đổi tên nhóm đã làm đổi vị trí trong thứ tự tuỳ chỉnh; giữ đúng vị trí cũ.
10. **Hết bộ nhớ cục bộ**: dữ liệu khi lưu có thể thất bại âm thầm; hiển thị cảnh báo. Doctor không thực hiện thay đổi có thể cần hoàn tác nếu không lưu được snapshot hoàn tác.

## Đã giữ nguyên

Nguồn M3U và sửa URL, danh sách kênh và yêu thích, nhóm/thư mục kéo thả, EPG/XMLTV, kiểm tra link, phát HLS, MultiView, Snapshot FFmpeg, Timeshift, failover, Doctor, PIN/Profiles, Cast/AirPlay, backup/restore, cập nhật bộ cài WebView có xác minh SHA256. `electron-original/` giữ làm baseline/test. Không xóa file dữ liệu trên máy.

## Giới hạn xác minh — cần biết trước khi phát hành

**Chưa có build DMG/EXE thực tế trên macOS/Windows** trong môi trường này, vì không có toolchain Rust/Tauri và máy macOS/Windows; do đó không thể xác nhận 100% chức năng native.

**Chưa xác minh ngoài đời thực**: phát HLS/DRM từ mạng của người dùng, máy Mac WKWebView thực, Windows WebView2 thực, FFmpeg đóng gói và Snapshot trên các stream thực, Timeshift, AirPlay/Chromecast trong LAN, code-signing/notarization và cơ chế cập nhật tại máy cài đặt. Test UI nói trên là Chrome giả lập, **không thay thế** thử ứng dụng WebView native. QA báo 82/82 và 39/39 là số bài kiểm thử, **không phải tỉ lệ 100% tính năng**.

Backup không chứa file ảnh JPG Snapshot rời hoặc Timeshift cache; metadata Snapshot có thể còn nhưng ảnh JPG sẽ không tồn tại trên máy mới nếu không tự chép ảnh. File backup chưa mã hóa, cần bảo mật nếu chứa URL và dữ liệu hồ sơ.

## Chạy test nguồn (Mac)

```bash
cd ~/Downloads/Open_IPTV_Pro_WebView_v4_22_0_AUDITED
bash TEST_ALL.command
```

## Build DMG trên Mac

```bash
cd ~/Downloads/Open_IPTV_Pro_WebView_v4_22_0_AUDITED
bash BUILD_MAC.command
```

Bước `npm install` cần Internet. Script có kiểm tra Node/Rust/FFmpeg, cài dependencies, chạy test và build Tauri. Sau khi build thành công DMG ở `~/Downloads/OpenIPTV_WebView_FULL_DMG/`, log `~/Downloads/OpenIPTV_WebView_FULL_build.log`.

## Push GitHub đúng nhánh (chỉ sau khi tự kiểm tra bản native)

```bash
cd ~/Downloads/Open_IPTV_Pro_WebView_v4_22_0_AUDITED
bash PUSH_GITHUB_MAC.command
```

Nhánh: **`experiment/native-webview-ffmpeg`**. Đích mã nguồn: `experiments/webview-full/`. Không force-push và không sửa nhánh `main`. Môi trường tạo gói này **chưa đăng GitHub/push**.

## Kiểm tra UI tái lập (tùy chọn)

`qa/ui_runtime_smoke.py`, `qa/native_batch_smoke.py`, `qa/backup_confirm_smoke.py` yêu cầu Python Playwright và Chromium (không bắt buộc khi build). Kiểm tra UI vẫn chạy headless giả lập, không kiểm tra Tauri native.
