@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo OPEN IPTV PRO WEBVIEW 4.23.37 - WINDOWS NSIS BUILD
 echo This builds TAURI/WEBVIEW2 - NOT Electron.
echo ========================================================
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_WINDOWS.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo Build FAILED, code %RESULT%.
  echo See: %USERPROFILE%\Downloads\OpenIPTV_WebView_Windows_Build.log
) else (
  echo Build completed. See Downloads\OpenIPTV_WebView_FULL_Setup
)
echo.
pause
exit /b %RESULT%
