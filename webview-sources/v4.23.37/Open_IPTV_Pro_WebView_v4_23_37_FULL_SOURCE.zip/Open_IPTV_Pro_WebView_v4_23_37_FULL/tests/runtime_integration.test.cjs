'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const http = require('node:http');
const {once} = require('node:events');
const path = require('node:path');

async function listen(server){server.listen(0,'127.0.0.1');await once(server,'listening');return 'http://127.0.0.1:'+server.address().port;}
async function startBackend(){
 const child=spawn(process.execPath,[path.resolve(__dirname,'../backend/main.cjs')],{stdio:['ignore','pipe','pipe'],env:{...process.env,OPEN_IPTV_FFMPEG:process.env.OPEN_IPTV_FFMPEG||'ffmpeg'}});
 const chunks=[];let stderr='';child.stderr.on('data',b=>{stderr+=b.toString()});
 return await new Promise((resolve,reject)=>{
  const timeout=setTimeout(()=>{child.kill();reject(Error('Backend timeout: '+stderr))},8000);
  child.stdout.on('data',b=>{
   chunks.push(b.toString());const text=chunks.join('');const m=text.match(/OPEN_IPTV_BACKEND_READY:(\{[^\r\n]+\})/);
   if(m){clearTimeout(timeout);resolve({child,...JSON.parse(m[1])});}
  });child.once('exit',()=>{clearTimeout(timeout);reject(Error('Backend exit early: '+stderr))});
 });
}
const fixture=http.createServer((req,res)=>{
 if(req.url==='/tv.m3u')return res.writeHead(200,{'Content-Type':'audio/x-mpegurl'}).end('#EXTM3U\n#EXTINF:-1,TV\nhttp://example.invalid/live.m3u8\n');
 if(req.url==='/live/master.m3u8')return res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl'}).end('#EXTM3U\n#EXT-X-TARGETDURATION:3\n#EXTINF:3,\nseg.ts\n');
 if(req.url==='/live/seg.ts')return res.writeHead(206,{'Content-Type':'video/mp2t','Content-Range':'bytes 0-3/6','Content-Length':'4'}).end(Buffer.from([0x47,1,2,3]));
 res.writeHead(404).end();
});
test('native Node backend: authenticated RPC, playlist import, HLS proxy rewrite, range, invalid origins',async()=>{
 const base=await listen(fixture);
 const backend=await startBackend();
 const api=`http://127.0.0.1:${backend.port}`,secret=backend.secret;
 async function rpc(method,...args){const r=await fetch(`${api}/rpc?key=${secret}`,{method:'POST',headers:{'Content-Type':'application/json','X-IPTV-Key':secret,'Origin':'tauri://localhost'},body:JSON.stringify({method,args})});return {status:r.status,body:await r.json()};}
 try{
  const c=await rpc('app:capabilities');assert.equal(c.status,200);assert.equal(c.body.ok,true);assert.equal(c.body.data.native,true);
  const source=await rpc('source:readUrl',base+'/tv.m3u');assert.match(source.body.data.content,/#EXTINF/);
  const proxy=await rpc('media:proxy',base+'/live/master.m3u8');assert.equal(proxy.body.ok,true);
  const manifest=await fetch(proxy.body.data);assert.equal(manifest.status,200);
  const content=await manifest.text();assert.match(content,/#EXT-X-TARGETDURATION/);assert.match(content,/\/stream\?key=/);assert.doesNotMatch(content,/^seg\.ts$/m);
  const segment=new URL(content.split('\n').find(x=>x.includes('/stream?key=')));
  const bytes=await fetch(segment,{headers:{'Range':'bytes=0-3'}});assert.equal(bytes.status,206);assert.equal((await bytes.arrayBuffer()).byteLength,4);
  const noSecret=await fetch(api+'/rpc',{method:'POST'});assert.equal(noSecret.status,403);
  const evil=await fetch(api+`/rpc?key=${secret}`,{method:'POST',headers:{'Origin':'https://evil.example','X-IPTV-Key':secret}});assert.equal(evil.status,403);
  const invalid=await rpc('invalid:method');assert.equal(invalid.body.ok,false);
  const update=await rpc('update:status');assert.equal(update.body.ok,true);
 }finally{backend.child.kill('SIGTERM');await new Promise(r=>setTimeout(r,70));await new Promise(r=>fixture.close(r));}
});
