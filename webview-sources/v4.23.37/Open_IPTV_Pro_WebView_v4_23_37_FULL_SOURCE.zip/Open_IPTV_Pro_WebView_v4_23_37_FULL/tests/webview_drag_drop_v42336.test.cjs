'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const vm=require('node:vm');
const sandbox={module:{exports:{}}};
vm.runInNewContext(read('frontend/channel-order.js'),sandbox);
const order=sandbox.module.exports;
const tauri=JSON.parse(read('src-tauri/tauri.conf.json'));

test('Tauri disables native drop interception so internal HTML5 DnD works on Windows',()=>{
 assert.equal(tauri.app.windows[0].dragDropEnabled,false);
 assert.equal(tauri.version,'4.23.37');
});
test('Pointer reorder handles channel, folder and cross-folder drop without reloading',()=>{
 const js=read('frontend/app.js'),css=read('frontend/styles.css');
 for(const fragment of ['pointerSortMove','pointerSortEnd',"document.addEventListener('pointerdown'",'document.elementFromPoint','applyChannelMove(ids,drop.group','reorderGroup(origin,drop.group)',"row.dataset.group=group",'pointerSort.clickGuardUntil']){
  assert.ok(js.includes(fragment),`missing pointer interaction: ${fragment}`);
 }
 assert.match(js,/card\.draggable=!window\.PointerEvent/);
 assert.match(js,/row\.draggable=!window\.PointerEvent/);
 assert.match(css,/\.iptv-drag-ghost/);
 assert.match(css,/channel-drop-before/);
 assert.match(css,/channel-drop-after/);
});
test('Core move persists ordered channels across groups and folders',()=>{
 const store={channels:[{id:'a',group:'A'},{id:'b',group:'A'},{id:'c',group:'A'},{id:'d',group:'B'}],channelOrder:{A:['a','b','c'],B:['d']},groupOrder:['A','B']};
 assert.equal(order.move(store,['a'],'A',{anchorId:'c',after:true}),1);
 assert.deepEqual([...store.channelOrder.A],['b','c','a']);
 assert.equal(order.move(store,['b'],'B',{}),1);
 assert.deepEqual([...store.channelOrder.A],['c','a']);
 assert.deepEqual([...store.channelOrder.B],['d','b']);
 assert.equal(store.channels.find(c=>c.id==='b').group,'B');
 assert.equal(order.moveFolder(store,'B','A'),true);
 assert.deepEqual(store.groupOrder,['B','A']);
 order.reconcile(store);
 assert.deepEqual([...store.channelOrder.B],['d','b']);
});
