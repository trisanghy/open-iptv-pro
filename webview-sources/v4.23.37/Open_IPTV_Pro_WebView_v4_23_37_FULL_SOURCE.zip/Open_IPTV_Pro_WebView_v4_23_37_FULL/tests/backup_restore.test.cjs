'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const sandbox={module:{exports:{}},TextEncoder,Date,JSON};
vm.runInNewContext(readFileSync(path.join(__dirname,'../frontend/backup-core.js'),'utf8'),sandbox);
const backup=sandbox.module.exports;
function storage(initial={},failAt=null){
 const data=new Map(Object.entries(initial));
 return {data,getItem:key=>data.has(key)?data.get(key):null,
  setItem(key,val){if(key===failAt)throw Error('quota');data.set(key,String(val));},
  removeItem(key){if(key===failAt)throw Error('quota');data.delete(key);}};
}
const main=JSON.stringify({sources:[{url:'https://example.test/m3u'}],channels:[{name:'TV'}],favorites:['ch1'],folders:['VN'],snapshots:{'https://x':{file:'shot.jpg'}}});
const advanced=JSON.stringify({profiles:[{id:'admin',name:'Người lớn',child:false}],pin:'9876',alternates:{'x':['https://y']}});
const settings=JSON.stringify({appearanceMode:'dark',sources:[{url:'https://epg.example/guide.xml'}]});
test('backup: all key user settings and metadata can round-trip across installations',()=>{
 const src=storage({'open-iptv-pro-4':main,'open-iptv-pro-advanced-v1':advanced,'open-iptv-pro-settings-v1':settings,'open-iptv-pro-language':'en','open-iptv-pro-epg-v1':JSON.stringify({guide:{programmes:[]}})});
 const {content,summary}=backup.create(src);
 assert.equal(summary.channels,1);assert.equal(summary.profiles,1);assert.equal(summary.snapshotReferences,1);assert.equal(summary.epg,true);
 const dest=storage({'open-iptv-pro-4':'{"old":true}','unrelated-app':'stay'});
 const result=backup.restore(dest,content);
 assert.equal(result.folders,1);assert.equal(dest.getItem('open-iptv-pro-4'),main);
 assert.equal(dest.getItem('open-iptv-pro-advanced-v1'),advanced);
 assert.equal(dest.getItem('open-iptv-pro-language'),'en');
 assert.equal(dest.getItem('unrelated-app'),'stay');
});
test('backup: EPG cache optional and omitted cache is cleaned during replace',()=>{
 const src=storage({'open-iptv-pro-4':main,'open-iptv-pro-epg-v1':JSON.stringify({big:true})});
 const out=backup.create(src,{includeEPG:false});assert.equal(out.summary.epg,false);
 const dest=storage({'open-iptv-pro-4':'{}','open-iptv-pro-epg-v1':'{"stale":true}'});
 backup.restore(dest,out.content);assert.equal(dest.getItem('open-iptv-pro-epg-v1'),null);
});
test('backup: refuse corrupt or arbitrary JSON before touching current data',()=>{
 const dest=storage({'open-iptv-pro-4':main});
 for(const raw of ['{}','bad',JSON.stringify({format:backup.FORMAT,schemaVersion:2,storage:{}}),
  JSON.stringify({format:backup.FORMAT,schemaVersion:1,createdAt:new Date().toISOString(),storage:{'foreign-key':'{}'}}),
  JSON.stringify({format:backup.FORMAT,schemaVersion:1,createdAt:new Date().toISOString(),storage:{'open-iptv-pro-4':'{"channels":12}'}})]){
  assert.throws(()=>backup.restore(dest,raw));assert.equal(dest.getItem('open-iptv-pro-4'),main);
 }
});
test('backup: disk quota failure restores existing values without partial restore',()=>{
 const src=storage({'open-iptv-pro-4':'{"channels":[]}','open-iptv-pro-advanced-v1':advanced});
 const dest=storage({'open-iptv-pro-4':main,'open-iptv-pro-advanced-v1':'{}'},'open-iptv-pro-advanced-v1');
 assert.throws(()=>backup.restore(dest,backup.create(src).content),/thất bại/);
 assert.equal(dest.getItem('open-iptv-pro-4'),main);
 assert.equal(dest.getItem('open-iptv-pro-advanced-v1'),'{}');
});
test('backup: new native Tauri pickers and full Electron-compatible backup UI are integrated',()=>{
 const root=path.resolve(__dirname,'..');
 const html=readFileSync(path.join(root,'frontend/index.html'),'utf8');
 const bridge=readFileSync(path.join(root,'frontend/webview-bridge.js'),'utf8');
 const rust=readFileSync(path.join(root,'src-tauri/src/main.rs'),'utf8');
 const advanced=readFileSync(path.join(root,'frontend/advanced.js'),'utf8');
 const ui=readFileSync(path.join(root,'frontend/backup-ui.js'),'utf8');
 for(const id of ['backupSettings','backupExportBtn','backupImportBtn','backupIncludeSnapshots','backupStatus'])assert.match(html,new RegExp(`id="${id}"`));
 for(const method of ['backupExport','backupInspect','backupRestore','backupFinish','confirmBackupRestore'])assert.match(bridge,new RegExp(method));
 for(const cmd of ['pick_backup_open','pick_backup_save','native_confirm_restore'])assert.match(rust,new RegExp(cmd));
 assert.match(html,/backup-ui\.js/);assert.match(ui,/__openIPTVRestoringBackup/);assert.match(advanced,/__openIPTVRestoringBackup/);
});
