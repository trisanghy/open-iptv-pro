'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
function read(p){return fs.readFileSync(path.join(root,p),'utf8');}
const {parseM3U}=require('../backend/core.cjs');
test('M3U: quoted comma in group title does not split the channel name (backend + UI)',()=>{
 const m3u='#EXTM3U\n#extinf:-1 tvg-id="tv-1" group-title="News, Sports",Live, TV\nhttps://example.com/live.m3u8';
 const expected={group:'News, Sports',name:'Live, TV',tvgId:'tv-1'};
 assert.deepEqual(Object.fromEntries(['group','name','tvgId'].map(k=>[k,parseM3U(m3u)[0][k]])),expected);
 const sandbox={window:{},URL,Intl};vm.runInNewContext(read('frontend/core-browser.js'),sandbox);
 const c=sandbox.window.StreamLeafCore.parseM3U(m3u)[0];
 assert.deepEqual(Object.fromEntries(['group','name','tvgId'].map(k=>[k,c[k]])),expected);
});
test('bridge: no Tauri global means browser preview; reattempt backend_info after a temporary failure',async()=>{
 const raw=read('frontend/webview-bridge.js');
 const browser={window:{}};vm.runInNewContext(raw,browser);assert.equal(browser.window.streamleaf,undefined);
 let attempts=0;
 const win={__TAURI__:{core:{invoke:async()=>{attempts++;if(attempts===1)throw Error('not ready');return {port:3033,secret:'safe'};}}}};
 const sandbox={window:win,fetch:async()=>({ok:true,json:async()=>({ok:true,data:{native:true}})}),AbortController,JSON,setInterval:()=>1,clearInterval:()=>{},setTimeout,clearTimeout};
 vm.runInNewContext(raw,sandbox);
 await assert.rejects(win.streamleaf.capabilities(),/not ready/);
 assert.equal((await win.streamleaf.capabilities()).native,true);
 assert.equal(attempts,2);
});
test('restore rejects malformed nested channels and profiles without changing current storage',()=>{
 const sandbox={module:{exports:{}},TextEncoder,Date,JSON};vm.runInNewContext(read('frontend/backup-core.js'),sandbox);
 const backup=sandbox.module.exports;
 const current=new Map([['open-iptv-pro-4','{"sources":[]}']]);
 const storage={getItem:k=>current.get(k)??null,setItem:(k,v)=>current.set(k,v),removeItem:k=>current.delete(k)};
 const bad=[{'open-iptv-pro-4':'{"channels":[null]}'},{'open-iptv-pro-advanced-v1':'{"profiles":[null]}'}, {'open-iptv-pro-4':'{"folders":[null]}'}, {'open-iptv-pro-advanced-v1':'{"alternates":{"x":"not-array"}}'}];
 for(const obj of bad){
  const payload=JSON.stringify({format:'open-iptv-pro-backup',schemaVersion:1,createdAt:new Date().toISOString(),storage:obj});
  assert.throws(()=>backup.restore(storage,payload));
  assert.equal(storage.getItem('open-iptv-pro-4'),'{"sources":[]}');
 }
});
test('UI: protected management actions and safe shortcut; multiview retains player on same tab',()=>{
 const app=read('frontend/app.js'),advanced=read('frontend/advanced.js'),backup=read('frontend/backup-ui.js');
 for(const action of ['addSource','loadFile','openURL','refreshAll','renameSource','deleteSource','checkAll','snapshotAll','exportFile']){
  const start=app.indexOf('function '+action+'(');
  assert.ok(start>=0,`${action} missing`);
  assert.match(app.slice(start,start+270),/canEdit\?\.\(\)===false/,`${action} missing child guard`);
 }
 assert.match(app,/target\?\.closest\?\.\('input, textarea, select, button/);
 assert.match(advanced,/p==='multiview'&&last!=='multiview'/);
 assert.match(backup,/confirmBackupRestore/);assert.doesNotMatch(backup,/if\(!confirm\(details\)\)/);
 assert.match(app,/start\+=1000/);
});
