'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const path=require('node:path');
const {checkWebViewRelease}=require('../backend/webview-updates.cjs');
const {identifyInstaller,UpdateManager}=require('../backend/update-manager.cjs');
const {compatibleAsset}=require('../backend/update-check.cjs');
const root=path.resolve(__dirname,'..');
const repo='trisanghy/open-iptv-pro';
const asset=(name,tag)=>({name,browser_download_url:`https://github.com/${repo}/releases/download/${tag}/${encodeURIComponent(name)}`,size:104,digest:'sha256:'+'a'.repeat(64)});
const release=(tag,names,id)=>({id,tag_name:tag,name:'Open IPTV Pro',assets:names.map(name=>asset(name,tag)),html_url:`https://github.com/${repo}/releases`});
const fakeAPI=(latest,history=[])=>async url=>({ok:true,status:200,url,json:async()=>url.includes('releases/latest')?latest:history});
test('Sync: v4.22 icon, settings, WebView bridge and in-app merge approval coexist',()=>{
 const html=readFileSync(path.join(root,'frontend/index.html'),'utf8');
 const css=readFileSync(path.join(root,'frontend/styles.css'),'utf8');
 const app=readFileSync(path.join(root,'frontend/app.js'),'utf8');
 const merge=readFileSync(path.join(root,'frontend/collector.js'),'utf8');
 assert.match(html,/app-icons\.js/);assert.match(css,/macos-nav-symbol/);
 assert.match(html,/Nhà phát hành chính thức/);assert.doesNotMatch(html,/id="releaseRepo"/);
 assert.match(html,/webview-bridge\.js/);assert.match(html,/hls\.min\.js/);
 assert.match(app,/runNativeBatch/);assert.match(app,/sourceAllowReduced/);
 assert.match(merge,/confirmInApp/);
 assert.match(readFileSync(path.join(root,'backend/main.cjs'),'utf8'),/batch:start/);
});
test('Sync: x64 and arm64 compatible with Tauri installer architecture naming',()=>{
 const choices=[{name:'Open IPTV Pro WebView Full_4.24.0_aarch64.dmg',url:'https://x'},
  {name:'Open IPTV Pro WebView Full_4.24.0_x86_64.dmg',url:'https://x'},
  {name:'Open IPTV Pro WebView Full_4.24.0_x64-setup.exe',url:'https://x'}];
 assert.match(compatibleAsset(choices,'darwin','arm64').name,/aarch64/);
 assert.match(compatibleAsset(choices,'darwin','x64').name,/x86_64/);
 assert.match(identifyInstaller(choices,'win32','x64').name,/setup\.exe/);
 assert.equal(identifyInstaller([{name:'Open-IPTV-Pro-Setup-4.24.0-x64.exe',url:'https://x'}],'win32','x64'),null);
});
test('Sync: latest Electron-only Release is skipped; WebView installer selected from earlier compatible release',async()=>{
 const chromium=release('release-v4.25.0',['Open-IPTV-Pro-Setup-4.25.0-x64.exe','SHA256SUMS.txt'],2);
 const webview=release('webview-v4.24.0',['Open IPTV Pro WebView Full_4.24.0_x64-setup.exe','SHA256SUMS.txt'],1);
 const result=await checkWebViewRelease(repo,'4.22.0',fakeAPI(chromium,[chromium,webview]),'win32','x64');
 assert.equal(result.latest,'v4.24.0');assert.equal(result.newer,true);
 assert.equal(result.assets.some(a=>/^(?!.*webview).*\.exe$/i.test(a.name)),false);
});
test('Sync: no Electron-only update ever offered as WebView update',async()=>{
 const desktop=release('v4.27.0',['Open-IPTV-Pro-4.27.0-mac-arm64.dmg','SHA256SUMS.txt'],20);
 const result=await checkWebViewRelease(repo,'4.22.0',fakeAPI(desktop,[desktop]),'darwin','arm64');
 assert.equal(result.noRelease,true);assert.equal(result.newer,false);
});
test('Sync: verified manual installation is the only Tauri update mode',async()=>{
 const rel=release('webview-4.23.0',['Open-IPTV-Pro-WebView-4.23.0-mac-arm64.dmg','SHA256SUMS.txt'],21);
 const fake=async()=>({current:'4.22.0',latest:'v4.23.0',newer:true,noRelease:false,assets:rel.assets.map(a=>({name:a.name,url:a.browser_download_url,digest:a.digest,size:a.size}))});
 const app={getVersion:()=> '4.22.0',getPath:()=>'/tmp'};
 const m=new UpdateManager({app,platform:'darwin',arch:'arm64',check:fake,updater:null,signatureCheck:()=>true});
 const state=await m.checkForUpdates();
 assert.equal(state.phase,'available');assert.equal(state.mode,'manual');
 assert.match(state.assetName,/WebView/);
});
