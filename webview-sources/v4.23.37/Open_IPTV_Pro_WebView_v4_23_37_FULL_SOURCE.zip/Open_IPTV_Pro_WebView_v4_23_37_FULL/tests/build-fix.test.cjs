const test=require('node:test');
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const {resolve}=require('node:path');
const root=resolve(__dirname,'..');
const pkg=require('../package.json');
const conf=require('../src-tauri/tauri.conf.json');
test('npm install does not implicitly trigger expensive asset prepare',()=>{
 assert.equal(Object.hasOwn(pkg.scripts,'prepare'),false);
 assert.equal(pkg.scripts.assets,'node scripts/prepare.mjs');
 assert.match(pkg.scripts.build,/npm run assets/);
});
test('no repeated Tauri beforeBuild/beforeDev asset preparation',()=>{
 assert.equal(conf.build.beforeBuildCommand,undefined);
 assert.equal(conf.build.beforeDevCommand,undefined);
});
test('mac build announces npm installation and asset stage',()=>{
 const sh=readFileSync(resolve(root,'BUILD_MAC.command'),'utf8');
 assert.match(sh,/--foreground-scripts --loglevel=info/);
 assert.match(sh,/npm run assets/);
 assert.doesNotMatch(sh,/npm run prepare/);
 assert.match(sh,/build --bundles dmg/);
});
test('windows build uses single explicit assets stage',()=>{
 const ps=readFileSync(resolve(root,'BUILD_WINDOWS.ps1'),'utf8');
 assert.match(ps,/npm run assets/);
 assert.match(ps,/--foreground-scripts/);
});
