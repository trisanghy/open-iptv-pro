'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const base = path.join(__dirname,'../frontend');
const read = (name) => fs.readFileSync(path.join(base,name),'utf8');

function makeUI() {
  const events = new Map(), attributes = {};
  const video = {videoWidth:0,videoHeight:0, addEventListener(name,fn){events.set(name,fn)}};
  const stage = {dataset:{},style:{setProperty(n,v){attributes[n]=v}}};
  const label = {textContent:'',title:''};
  const window = {};
  const document={getElementById(n){return {video,playerBox:stage,videoSourceRatio:label}[n]}};
  vm.runInNewContext(read('video-aspect-v42337.js'),{document,window});
  return {video,stage,label,events,attributes,window};
}

test('Video stage starts at 16:9 and detects intrinsic 4:3, 9:16 and cinematic streams',()=>{
  const t=makeUI();
  assert.equal(t.label.textContent,'16:9');
  t.video.videoWidth=1440;t.video.videoHeight=1080;t.events.get('loadedmetadata')();
  assert.equal(t.label.textContent,'4:3');
  assert.equal(t.attributes['--iptv-video-ratio'],'1440 / 1080');
  t.video.videoWidth=1080;t.video.videoHeight=1920;t.events.get('resize')();
  assert.equal(t.label.textContent,'9:16');
  t.video.videoWidth=2520;t.video.videoHeight=1080;t.events.get('resize')();
  assert.equal(t.label.textContent,'21:9');
});

test('Video stage resets to 16:9 on source replacement, stop, errors, or corrupted metadata',()=>{
  const t=makeUI();
  t.events.get('loadedmetadata')();
  t.video.videoWidth=640;t.video.videoHeight=480;t.events.get('loadedmetadata')();
  t.events.get('loadstart')();
  assert.equal(t.label.textContent,'16:9');
  t.video.videoHeight=0;t.events.get('resize')();
  assert.equal(t.label.textContent,'16:9');
  t.video.videoHeight=1;t.video.videoWidth=20000;t.events.get('resize')();
  assert.equal(t.label.textContent,'16:9');
  t.events.get('error')();
  assert.equal(t.label.textContent,'16:9');
});

test('Aspect CSS is last, covers all themes and does not stretch fullscreen',()=>{
  const html=read('index.html'),css=read('video-aspect-v42337.css');
  assert.ok(html.indexOf('player-two-row-v42335.css') < html.indexOf('video-aspect-v42337.css'));
  assert.match(html,/id="videoSourceRatio"/);
  assert.match(html,/video-aspect-v42337\.js/);
  assert.match(css, /#page-tv #playerBox:not\(:fullscreen\)/);
  assert.match(css, /aspect-ratio:\s*var\(--iptv-video-ratio\) !important/);
  assert.match(css, /#playerBox:fullscreen/);
  assert.match(css, /aspect-ratio: auto !important/);
});
