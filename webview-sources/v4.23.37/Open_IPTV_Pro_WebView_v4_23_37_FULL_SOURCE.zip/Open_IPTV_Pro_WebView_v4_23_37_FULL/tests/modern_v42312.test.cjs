'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const os=require('node:os');const vm=require('node:vm');const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const version='4.23.37';

test('v4.23.37 synced frontend, 11 themes & new feature UI load in Tauri with valid local asset paths',()=>{
 const html=read('frontend/index.html');const cfg=JSON.parse(read('src-tauri/tauri.conf.json'));
 assert.equal(cfg.version,version);assert.equal(JSON.parse(read('package.json')).version,version);
 assert.match(html,/webview-bridge\.js/);assert.doesNotMatch(html,/\.\.\/node_modules/);
 for(const name of ['doctor-v3.js','smart-discovery-ui.js','dvr-ui.js','ui-fullsync.css','ui-refined.css','theme-stage.js','settings-ui.js','backup-ui.js']){
  assert.ok(html.includes(name),name+' missing in HTML');assert.ok(fs.existsSync(path.join(root,'frontend',name)),name+' missing file');
 }
 assert.match(html,/Cinema TV/);assert.match(html,/Glassmorphism/);assert.match(html,/backupIncludeSnapshots/);
 for(const method of ['dvr:list','smart:countries','backup:export','backup:inspect','backup:restore','backup:finish','epg:importFile','batch:start'])assert.ok(read('backend/main.cjs').includes(`ipcMain.handle('${method}'`),method);
 assert.match(read('frontend/app.js'),/start\+=1000/);
});

test('WebView bridge exports all v4.23.37 native services and uses native file pickers',async()=>{
 const calls=[];const code=read('frontend/webview-bridge.js');const result={port:9890,secret:'s'};
 const window={__TAURI__:{core:{invoke:async(name,args)=>{calls.push({name,args});if(name==='backend_info')return result;if(name==='pick_dvr_directory')return '/tmp/test';if(name==='pick_backup_open')return '/tmp/demo.iptvbackup';if(name==='pick_epg_file')return '/tmp/demo.xml';if(name==='pick_backup_save')return '/tmp/demo.iptvbackup';return true;}}}};
 const fetch=async(url,opts)=>({ok:true,json:async()=>({ok:true,data:{url,method:JSON.parse(opts.body).method,args:JSON.parse(opts.body).args}})});
 vm.runInNewContext(code,{window,fetch,AbortController,setTimeout,clearTimeout,setInterval,clearInterval,Date,JSON,encodeURIComponent});
 const api=window.streamleaf;
 for(const name of ['dvrList','dvrCreate','dvrStop','dvrChooseDirectory','dvrOpenDirectory','dvrReveal','importEPGFile','backupExport','backupInspect','backupRestore','backupFinish','smartCountries','smartCountry','smartCatalogOptions','smartLoad','smartCheck','batchStart','batchStatus','batchCancel','confirmBackupRestore'])assert.equal(typeof api[name],'function',name);
 assert.equal((await api.dvrList()).method,'dvr:list');assert.equal((await api.smartCountry('vn')).method,'smart:country');
 await api.importEPGFile();await api.backupInspect();await api.backupExport({'open-iptv-pro-4':'{}'},false);await api.dvrChooseDirectory();
 for(const name of ['pick_epg_file','pick_backup_open','pick_backup_save','pick_dvr_directory'])assert.ok(calls.some(x=>x.name===name));
 assert.equal((await api.backupRestore('token')).method,'backup:restore');
});

test('Real Node IPC supports DVR listings, backup/restore and legacy v4.22 JSON import',async t=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'openiptv-v42312-test-'));
 const env={...process.env,XDG_CONFIG_HOME:temp};
 const child=spawn(process.execPath,[path.join(root,'backend/main.cjs')],{cwd:root,env,stdio:['ignore','pipe','pipe']});
 t.after(()=>{child.kill('SIGTERM');try{fs.rmSync(temp,{recursive:true,force:true});}catch{}});
 let ready;
 const information=await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(Error('Backend startup timeout')),10000);
  const onData=c=>{ready=(ready||'')+c.toString();const m=ready.match(/OPEN_IPTV_BACKEND_READY:(\{[^\r\n]*\})/);if(m){clearTimeout(timer);resolve(JSON.parse(m[1]));}};
  child.stdout.on('data',onData);child.on('exit',c=>{clearTimeout(timer);reject(Error('Backend exited '+c));});
 });
 const rpc=async(method,...args)=>{
  const res=await fetch(`http://127.0.0.1:${information.port}/rpc?key=${information.secret}`,{method:'POST',headers:{'Content-Type':'application/json','X-IPTV-Key':information.secret,'Origin':'http://tauri.localhost'},body:JSON.stringify({method,args}),signal:AbortSignal.timeout(5000)});
  assert.equal(res.status,200);return res.json();
 };
 const denial=await fetch(`http://127.0.0.1:${information.port}/rpc?key=${information.secret}`,{method:'POST',headers:{'X-IPTV-Key':information.secret,'Origin':'https://evil.example'},body:'{}'});
 assert.equal(denial.status,403);
 const listing=await rpc('dvr:list');assert.equal(listing.ok,true);assert.ok(Array.isArray(listing.data.jobs));
 const invalid=await rpc('smart:country','..');assert.equal(invalid.ok,false);
 const noEPG=await rpc('epg:importFile','../etc/hosts');assert.equal(noEPG.ok,false);
 const file=path.join(temp,'test.iptvbackup');
 const state={sources:[],channels:[],snapshots:{},favorites:[],folders:[]};
 const storage={'open-iptv-pro-4':JSON.stringify(state),'open-iptv-pro-language':'vi'};
 const exp=await rpc('backup:export',storage,false,file);assert.equal(exp.ok,true);assert.equal(exp.data.canceled,false);assert.ok(fs.statSync(file).size>0);
 const preview=await rpc('backup:inspect',file);assert.equal(preview.ok,true);assert.equal(preview.data.sourceCount,0);
 const restored=await rpc('backup:restore',preview.data.token);assert.equal(restored.ok,true);assert.deepEqual(JSON.parse(restored.data.storage['open-iptv-pro-4']).channels,[]);
 const final=await rpc('backup:finish',restored.data.finishToken,true);assert.equal(final.data,true);
 const legacy=require('../backend/legacy-backup-core.cjs');const map={getItem:k=>storage[k]??null};
 const old=legacy.create(map);const oldFile=path.join(temp,'old.json');fs.writeFileSync(oldFile,old.content);
 const oldPreview=await rpc('backup:inspect',oldFile);assert.equal(oldPreview.ok,true);assert.equal(oldPreview.data.legacy,true);
 const oldRestore=await rpc('backup:restore',oldPreview.data.token);assert.equal(oldRestore.ok,true);
 assert.equal((await rpc('backup:finish',oldRestore.data.finishToken,false)).data,true);
});
