# Checklist tính năng WebView 4.21.1

- [x] M3U URL / file, danh sách kênh, nhóm, yêu thích
- [x] Chỉnh URL nguồn M3U đã lưu, giữ thuộc tính kênh khớp
- [x] Collector / gộp / phục hồi, xác nhận trong WebView
- [x] Kiểm tra, Snapshot và sửa dự phòng ở Node backend 1–32 luồng
- [x] FFmpeg và FFprobe được cấu hình đóng gói trong installer
- [x] Timeshift FFmpeg 5 phút, chụp JPEG bằng FFmpeg
- [x] EPG, MultiView, Doctor, Failover, 8 ngôn ngữ, hồ sơ
- [x] Cast service + signed LAN relay + AirPlay Bonjour/Safari
- [x] WebView app có thể tải bộ cài WebView được kiểm tra SHA256
- [ ] Kiểm thử DMG thực trên macOS + codec HLS đa dạng
- [ ] Kiểm thử trên TV Google Cast thật, AirPlay receiver thật
- [ ] Kiểm thử installer và WebView2 trên Windows x64 thật
- [ ] Native updater Tauri ký số (hiện cài bản tải về thủ công)
