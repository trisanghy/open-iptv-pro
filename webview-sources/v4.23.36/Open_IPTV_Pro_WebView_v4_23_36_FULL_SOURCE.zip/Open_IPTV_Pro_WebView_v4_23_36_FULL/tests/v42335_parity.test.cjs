'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {once}=require('node:events');
const root=path.resolve(__dirname,'..');
const read=(name)=>fs.readFileSync(path.join(root,name),'utf8');

test('WebView hotfix 4.23.36 builds on Electron reference 4.23.35',()=>{
 const pkg=require('../package.json');
 assert.equal(pkg.version,'4.23.36');
 assert.equal(require('../backend/package.json').version,'4.23.36');
 assert.equal(require('../electron-original/package.json').version,'4.23.35');
 assert.match(read('src-tauri/Cargo.toml'),/version = "4\.23\.36"/);
 assert.equal(JSON.parse(read('src-tauri/tauri.conf.json')).version,'4.23.36');
 assert.match(read('frontend/index.html'),/4\.23\.36/);
});

test('two-row controls and 11 theme CSS are present, all script and stylesheet names are local',()=>{
 const html=read('frontend/index.html');
 for(const tag of [...html.matchAll(/<(?:script|link)\b[^>]*?(?:src|href)="([^"]+)"/g)]){
  const asset=tag[1];
  if(/^https?:/.test(asset))throw Error('Nonlocal JS/CSS '+asset);
  // HLS/DASH are generated at build time, in src-tauri assets stage.
  if(['hls.min.js','dash.all.min.js'].includes(asset))continue;
  assert.ok(fs.existsSync(path.join(root,'frontend',asset)), 'Missing local asset '+asset);
 }
 for(const required of ['player-two-row-v42335.css','sidebar-channel-align-v42334.css','channel-panel-compact-v42333.css','video-layout-fix-v42330.css','sidebar-link-picker-v42329.css'])assert.ok(html.includes(required));
 for(const required of ['player-ux.js','sidebar-channel-align-v42334.js','channel-order.js','manual-stream-selection.js','startup-policy.js','playback-preference.js','webview-bridge.js'])assert.ok(html.includes(required));
 assert.ok(html.includes('id="sidebarToggleBtn"'));
 assert.ok(html.includes('id="channelBatchPosition"'));
});

test('new renderer controls keep genuine Tauri services and WebView legacy features',()=>{
 const bridge=read('frontend/webview-bridge.js'),backend=read('backend/main.cjs');
 for(const method of ['startPlaybackFallback','stopPlaybackFallback','playbackFallbackStatus','startTimeshift','batchStart','batchStatus','batchCancel','backupExport','backupRestore','dvrCreate','smartCountry'])assert.match(bridge,new RegExp('\\b'+method+'\\s*:'));
 for(const rpc of ['playback:fallback:start','playback:fallback:stop','playback:fallback:status','batch:start','backup:restore','dvr:create'])assert.ok(backend.includes(rpc));
 assert.match(backend,/pathname==='\/playback-fallback'/);
 assert.match(backend,/inspectMedia\(/);
 assert.ok(read('scripts/prepare.mjs').includes('dash.all.min.js'));
 assert.ok(read('scripts/prepare.mjs').includes('hls.min.js'));
 assert.ok(!bridge.includes('require(\'electron\')'));
});

test('native fallback serves only whitelisted HLS segment names, not arbitrary paths',()=>{
 const fallback=require('../backend/playback-fallback.cjs');
 assert.throws(()=>fallback.safeMediaUrl('file:///etc/passwd'),/HTTP/);
 assert.throws(()=>fallback.safeMediaUrl('http://user:password@x.test/live'),/mật khẩu/);
 const instance=fallback.createPlaybackFallback({baseDir:'/tmp/openiptv-fallback-tests',ffmpegPath:'ffmpeg'});
 assert.deepEqual(instance.status(),{active:false});
 assert.throws(()=>instance.read('x','../../etc/passwd'),/Tên file/);
 assert.throws(()=>instance.read('x','segment_1.ts'),/Tên file/);
});

test('Windows/macOS build scripts use Tauri, Github push targets isolated WebView branch',()=>{
 assert.match(read('BUILD_MAC.command'),/tauri build --bundles dmg/);
 assert.match(read('BUILD_WINDOWS.ps1'),/tauri.+build/);
 assert.match(read('PUSH_GITHUB_MAC.command'),/experiment\/native-webview-ffmpeg/);
 assert.match(read('PUSH_GITHUB_MAC.command'),/build-native-webview-v42335\.yml/);
 assert.match(read('PUSH_GITHUB_MAC.command'),/without force|KHÔNG force|không force/i);
 assert.doesNotMatch(read('BUILD_WINDOWS.ps1'),/Run 'Tauri build'.*electron-builder/);
});

test('backend exposes new playback RPC service over authenticated localhost',async()=>{
 const child=spawn(process.execPath,[path.join(root,'backend/main.cjs')],{stdio:['ignore','pipe','pipe']});
 let stderr='';child.stderr.on('data',data=>{stderr+=data.toString();});
 let ready='';
 const info=await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{child.kill();reject(new Error('backend not ready '+stderr));},8000);
  child.stdout.on('data',chunk=>{ready+=chunk.toString();const match=ready.match(/OPEN_IPTV_BACKEND_READY:(\{[^\n]+\})/);if(match){clearTimeout(timer);resolve(JSON.parse(match[1]));}});
  child.once('exit',()=>{clearTimeout(timer);reject(new Error('Backend exited: '+stderr));});
 });
 const endpoint=`http://127.0.0.1:${info.port}`;
 const rpc=async(method,...args)=>{const response=await fetch(`${endpoint}/rpc?key=${info.secret}`,{method:'POST',headers:{'Content-Type':'application/json','X-IPTV-Key':info.secret,'Origin':'tauri://localhost'},body:JSON.stringify({method,args})});return response.json();};
 try{
  const status=await rpc('playback:fallback:status');assert.deepEqual(status,{ok:true,data:{active:false}});
  const rejected=await rpc('playback:fallback:start','file:///etc/passwd');assert.equal(rejected.ok,false);
  const invalid=await fetch(`${endpoint}/playback-fallback?key=${info.secret}&id=x&file=../bad.txt`);assert.equal(invalid.status,404);
  const denied=await fetch(`${endpoint}/rpc?key=${info.secret}`,{method:'POST',headers:{'Origin':'https://evil.example','X-IPTV-Key':info.secret}});assert.equal(denied.status,403);
 }finally{child.kill('SIGTERM');await new Promise(r=>setTimeout(r,100));}
});
