const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=(rel)=>fs.readFileSync(path.join(root,rel),'utf8');
test('WebView launcher targets the dedicated Tauri script, not Electron',()=>{
 const cmd=read('BUILD_WINDOWS.cmd');
 assert.match(cmd,/cd \/d "%~dp0"/);
 assert.match(cmd,/BUILD_WINDOWS\.ps1/);
 assert.doesNotMatch(cmd,/electron-builder/i);
});
test('WebView builds anchored to its root and checks package identity',()=>{
 const ps=read('BUILD_WINDOWS.ps1');
 assert.match(ps,/Set-Location -LiteralPath \$root/);
 assert.match(ps,/\$pkg\.name -ne 'open-iptv-pro-webview-full'/);
 assert.match(ps,/tauri','build','--bundles','nsis/);
 assert.doesNotMatch(ps,/electron-builder --win/);
});
test('WebView tests and binaries are generated before packaging',()=>{
 const ps=read('BUILD_WINDOWS.ps1');
 for(const pattern of [/test:original/,/test:bridge/,/run','assets/,/OpenIPTV_WebView_Windows_Build\.log/,/OpenIPTV_WebView_FULL_Setup/]) assert.match(ps,pattern);
});
test('Electron reference build script delegates to safe PowerShell project root build',()=>{
 const bat=read('electron-original/BUILD_WINDOWS.bat');
 const ps=read('electron-original/scripts/BUILD_WINDOWS_AUTO.ps1');
 assert.match(bat,/BUILD_WINDOWS_AUTO\.ps1/);
 assert.match(ps,/\$PSScriptRoot/);
 assert.match(ps,/--projectDir "\$root"/);
 assert.match(ps,/electron-builder/);
});
test('Each separate source has its own valid package metadata',()=>{
 const web=JSON.parse(read('package.json'));
 const electron=JSON.parse(read('electron-original/package.json'));
 assert.equal(web.name,'open-iptv-pro-webview-full');
 assert.equal(electron.name,'open-iptv-pro');
 assert.equal(web.version,'4.23.36');
 assert.equal(electron.version,'4.23.35');
});
