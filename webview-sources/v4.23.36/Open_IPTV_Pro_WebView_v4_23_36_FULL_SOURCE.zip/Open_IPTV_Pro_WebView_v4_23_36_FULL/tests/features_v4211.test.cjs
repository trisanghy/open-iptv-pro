'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const root=path.join(__dirname,'..');
const file=(x)=>fs.readFileSync(path.join(root,x),'utf8');

test('WebView 4.22 includes source URL editing, Cast, Safari AirPlay, and 32-worker bridge',()=>{
 const html=file('frontend/index.html'),ui=file('frontend/app.js'),bridge=file('frontend/webview-bridge.js'),backend=file('backend/main.cjs');
 const expected=['source-edit.js','cast-ui.js','webview-bridge.js','hls.min.js'];
 for(const f of expected)assert.match(html,new RegExp(f.replace('.','\\.')));
 assert.ok(html.indexOf('webview-bridge.js')<html.indexOf('app.js'));
 assert.ok(html.indexOf('source-edit.js')<html.indexOf('app.js'));
 assert.ok(html.indexOf('cast-ui.js')>html.indexOf('app.js'));
 assert.match(ui,/sourceAllowReduced/);assert.match(ui,/replaceURLSource/);
 for(const k of ['castDiscover','airplayDiscover','castPlay','castStop','castStatus','castLan','openAirplay','batchStart','batchStatus','batchCancel'])assert.match(bridge,new RegExp('\\b'+k+'\\b'));
 for(const k of ['cast:discover','airplay:discover','cast:play','cast:stop','cast:status','cast:lan','airplay:open','batch:start'])assert.ok(backend.includes("'"+k+"'"),k);
 assert.match(backend,/createSnapshotEngine/);
 assert.match(backend,/createBatchJobs/);
});

test('Tauri version and installer bundle remain complete: Node/FFmpeg/FFprobe',()=>{
 const conf=JSON.parse(file('src-tauri/tauri.conf.json'));
 const pkg=JSON.parse(file('package.json'));
 const backendPkg=JSON.parse(file('backend/package.json'));
 assert.equal(conf.version,'4.23.36');assert.equal(pkg.version,'4.23.36');
 assert.equal(conf.bundle.targets,'all');
 assert.deepEqual(conf.bundle.externalBin,['binaries/iptv-node','binaries/ffmpeg','binaries/ffprobe']);
 assert.equal(backendPkg.dependencies['bonjour-service'],'1.4.4');
 assert.equal(backendPkg.dependencies['castv2-client'],'1.2.0');
 assert.match(file('scripts/prepare.mjs'),/--prefix','backend/);
});

test('AirPlay Bonjour list parser recognizes receivers but does not invent missing devices',async()=>{
 const {parseAirplayLine,discoverAirplay}=require('../backend/airplay-discovery.cjs');
 const v=parseAirplayLine('Add 2 9 local. _airplay._tcp. Phòng khách TV');
 assert.deepEqual(v,{action:'add',name:'Phòng khách TV'});
 assert.equal(parseAirplayLine('garbage'),null);
 assert.deepEqual(await discoverAirplay({platform:'win32'}),[]);
});

test('LAN Cast relay returns a functioning HLS manifest and media URLs with authorization',async()=>{
 const {CastRelay}=require('../backend/cast-relay.cjs');
 const source=http.createServer((req,res)=>{
  if(req.url==='/tv.m3u8'){res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl'});res.end('#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:4,\nchunk.ts\n');}
  else if(req.url==='/chunk.ts'){res.writeHead(200,{'Content-Type':'video/mp2t'});res.end(Buffer.from([0x47,1,2,3]));}
  else{res.writeHead(404);res.end();}
 });
 await new Promise(resolve=>source.listen(0,'127.0.0.1',resolve));
 const src=`http://127.0.0.1:${source.address().port}/tv.m3u8`;
 const relay=new CastRelay({hostSelector:async()=> '127.0.0.1'});
 try{
  const session=await relay.start(src);
  const page=await fetch(session.page);assert.equal(page.status,200);assert.match(await page.text(),/video/);
  const manifest=await fetch(session.url);assert.equal(manifest.status,200);
  const body=await manifest.text();assert.match(body,/\/media\//);assert.match(body,/sig=/);
  const seg=body.split('\n').find(x=>x.includes('/media/'));
  const result=await fetch(seg);assert.equal(result.status,200);assert.equal((await result.arrayBuffer()).byteLength,4);
  const corrupted=new URL(seg);corrupted.searchParams.set('sig','1234');
  assert.equal((await fetch(corrupted)).status,403);
 }finally{await relay.stop();await new Promise(resolve=>source.close(resolve));}
});
