'use strict';
const {app,BrowserWindow,dialog,ipcMain,shell,nativeTheme} = require('./electron-compat.cjs');
const path=require('node:path');
const fs=require('node:fs');
const http=require('node:http');
const {randomBytes,createHash}=require('node:crypto');
const {spawn,spawnSync}=require('node:child_process');
const {checkRepeated}=require('./stream-check.cjs');
const {createBatchJobs}=require('./batch-jobs.cjs');
const {pipeContinuousResponse}=require('./stream-response.cjs');
const {rewriteHls}=require('./core.cjs');
const {fetchGuide,readGuideFile}=require('./epg.cjs');
const {UpdateManager}=require('./update-manager.cjs');
const {listPublicPlaylists}=require('./repo-sources.cjs');
const smartDiscovery=require('./smart-discovery.cjs');
const {createRecordingScheduler}=require('./recording-scheduler.cjs');
const backupService=require('./backup-service.cjs');
const legacyBackup=require('./legacy-backup-core.cjs');
const {createTimeshift}=require('./timeshift.cjs');
const {createPlaybackFallback}=require('./playback-fallback.cjs');
const {inspectMedia}=require('./media-inspection.cjs');
const {CastService}=require('./cast-service.cjs');
const {discoverAirplay}=require('./airplay-discovery.cjs');
const secret=randomBytes(20).toString('hex');
let webWindow, server, port, timeshift, playbackFallback, updates, dvr;
let pendingBackup=null,pendingRestore=null;
const mediaKindCache=new Map();
const castService=new CastService();
const MAX_PLAYLIST=25*1024*1024;
function urlOK(raw){const u=new URL(raw);if(!['http:','https:'].includes(u.protocol))throw new Error('Chỉ hỗ trợ URL http/https.');return u;}
function fileSafeName(s){return String(s).replace(/[^\p{L}\p{N}_.-]+/gu,'_').slice(0,80)||'channel';}
async function readURL(raw,maxBytes=MAX_PLAYLIST,timeout=18000){
 urlOK(raw);const c=new AbortController();const t=setTimeout(()=>c.abort(),timeout);
 try {const res=await fetch(raw,{signal:c.signal,redirect:'follow',headers:{'User-Agent':'Open-IPTV-Pro/4.23.36'}});
   if(!res.ok)throw new Error(`Máy chủ trả HTTP ${res.status}`);
   const parts=[];let len=0;
   for await(const chunk of res.body){len+=chunk.length;if(len>maxBytes)throw new Error('Playlist quá lớn');parts.push(chunk);}
   return Buffer.concat(parts).toString('utf8').replace(/^\uFEFF/,'');
 }finally{clearTimeout(t);}
}
function proxyUrl(u){return `http://127.0.0.1:${port}/stream?key=${secret}&url=${encodeURIComponent(u)}`;}
function allowedOrigins(res){res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Range,Accept,Content-Type,X-IPTV-Key');res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');res.setHeader('Access-Control-Expose-Headers','Content-Length, Content-Range, Accept-Ranges');}
async function handleStream(req,res){
 allowedOrigins(res);
 if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
 try {
  const local=new URL(req.url,'http://127.0.0.1');
  if(local.searchParams.get('key')!==secret){res.writeHead(403);res.end();return;}
if(local.pathname==='/rpc'){
  // Localhost API is never exposed to another origin. It uses a random 160-bit key.
  const origin=req.headers.origin||'';
  if(req.method!=='POST'||(origin&&!['tauri://localhost','http://tauri.localhost','https://tauri.localhost'].includes(origin))){res.writeHead(403);res.end();return;}
  if(req.headers['x-iptv-key']!==secret){res.writeHead(403);res.end();return;}
  let n=0;const parts=[];
  try {
    for await(const part of req){n+=part.length;if(n>28*1024*1024)throw Error('Yêu cầu quá lớn');parts.push(part);}
    const payload=JSON.parse(Buffer.concat(parts).toString('utf8'));
    if(typeof payload.method!=='string'||!Array.isArray(payload.args)||payload.args.length>8)throw Error('Yêu cầu không hợp lệ');
    const handler=ipcMain.__handlers.get(payload.method);
    if(!handler)throw Error('Chức năng không được hỗ trợ');
    const data=await handler(null,...payload.args);
    const reply=Buffer.from(JSON.stringify({ok:true,data:data===undefined?null:data}));
    res.writeHead(200,{'Content-Type':'application/json','Content-Length':reply.length,'Cache-Control':'no-store'});res.end(reply);return;
  }catch(e){const reply=Buffer.from(JSON.stringify({ok:false,error:String(e.message||e).slice(0,350)}));res.writeHead(200,{'Content-Type':'application/json','Content-Length':reply.length});res.end(reply);return;}
}
  if(local.pathname==='/snapshot'){
    const name=local.searchParams.get('file')||'';
    if(!/^[\p{L}\p{N}_.-]{1,160}\.jpg$/u.test(name)){res.writeHead(400);res.end();return;}
    const filename=path.join(app.getPath('userData'),'snapshots',name);
    try{const st=await fs.promises.stat(filename);if(!st.isFile()||st.size>5_000_000)throw Error('Invalid file');
      res.writeHead(200,{'Content-Type':'image/jpeg','Content-Length':st.size,'Cache-Control':'private, max-age=3600','X-Content-Type-Options':'nosniff'});
      fs.createReadStream(filename).pipe(res);return;
    }catch{res.writeHead(404);res.end();return;}
  }
  if(local.pathname==='/playback-fallback'){
    try{
      const id=local.searchParams.get('id')||'',file=local.searchParams.get('file')||'';
      const item=playbackFallback.read(id,file);let payload=item.data;
      if(file==='index.m3u8'){
        const lines=payload.toString('utf8').split(/\r?\n/).map(line=>{
          const name=line.trim();
          return /^segment_\d{6}\.ts$/.test(name)?`http://127.0.0.1:${port}/playback-fallback?key=${secret}&id=${encodeURIComponent(id)}&file=${name}`:line;
        });payload=Buffer.from(lines.join('\n'));
      }
      res.writeHead(200,{'Content-Type':item.contentType,'Content-Length':payload.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      res.end(payload);return;
    }catch(e){res.writeHead(404);res.end('Media unavailable');return;}
  }
  if(local.pathname==='/buffer'){
    try{
     const id=local.searchParams.get('id')||'',file=local.searchParams.get('file')||'';
     const item=timeshift.read(id,file);let payload=item.data;
     if(file.endsWith('.m3u8')){
       const lines=payload.toString('utf8').split(/\r?\n/).map(line=>{
         const item=line.trim();
         return /^segment_\d{6}\.ts$/.test(item)?`http://127.0.0.1:${port}/buffer?key=${secret}&id=${encodeURIComponent(id)}&file=${item}`:line;
       });payload=Buffer.from(lines.join('\n'));
     }
     res.writeHead(200,{'Content-Type':item.contentType,'Content-Length':payload.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(payload);return;
    }catch(e){res.writeHead(404);res.end(String(e.message||e));return;}
  }
  if(local.pathname!=='/stream'){res.writeHead(404);res.end();return;}
  const url=local.searchParams.get('url');urlOK(url);
  const ctrl=new AbortController();
  const timeout=setTimeout(()=>ctrl.abort(),25000); // connect / first response timeout ONLY
  const range=req.headers.range;
  const upstream=await fetch(url,{signal:ctrl.signal,redirect:'follow',headers:{'User-Agent':'Open-IPTV-Pro/4.23.36',...(range?{Range:range}:{})}});
  const ctype=upstream.headers.get('content-type')||'';
  const maybeHls=/\.m3u8?(?:$|\?)/i.test(upstream.url)||/mpegurl/i.test(ctype);
  const headers={'Content-Type':ctype||'application/octet-stream','Cache-Control':'no-store','Accept-Ranges':upstream.headers.get('accept-ranges')||'bytes'};
  if(upstream.headers.get('content-range'))headers['Content-Range']=upstream.headers.get('content-range');
  if(maybeHls&&upstream.ok){
    // Bound memory while reading HLS manifests; abort oversized responses promptly.
    const fragments=[];let bytes=0;
    for await (const chunk of upstream.body){bytes+=chunk.byteLength;if(bytes>5*1024*1024){ctrl.abort();throw Error('Manifest quá lớn');}fragments.push(Buffer.from(chunk));}
    const txt=Buffer.concat(fragments).toString('utf8');
    if(/#EXT-X-/i.test(txt)){
      const rewritten=rewriteHls(txt,upstream.url,proxyUrl);
      const b=Buffer.from(rewritten,'utf8');res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);
    }else{res.writeHead(upstream.status,headers);res.end(txt);}
    clearTimeout(timeout);return;
  }
  if(!upstream.ok){res.writeHead(upstream.status,headers);res.end();clearTimeout(timeout);return;}
  const l=upstream.headers.get('content-length');if(l)headers['Content-Length']=l;
  // A perpetual MPEG-TS/MP4 stream must not be aborted 25 seconds after it starts.
  // Timeouts apply to the upstream handshake, never to a healthy active response.
  pipeContinuousResponse({upstream,response:res,controller:ctrl,connectTimeout:timeout,headers});
 }catch(e){if(!res.headersSent)res.writeHead(502,{'Content-Type':'text/plain; charset=utf-8'});res.end('Không thể tải luồng: '+String(e.message||e).slice(0,200));}
}
async function startProxy(){
 server=http.createServer(handleStream);
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>{port=server.address().port;resolve();});});
}
// Full build: the platform-specific FFmpeg binary is bundled with the application.
// Electron Builder unpacks executable binaries from app.asar to app.asar.unpacked.
let resolvedFfmpeg;
function ffmpegPath(){
 if(resolvedFfmpeg!==undefined)return resolvedFfmpeg;
 const executable=process.platform==='win32'?'ffmpeg.exe':'ffmpeg';
 const choices=[];
 try{
  const embedded=require('ffmpeg-static');
  if(embedded){
   choices.push(embedded);
   if(embedded.includes('app.asar'))choices.unshift(embedded.replace('app.asar','app.asar.unpacked'));
  }
 }catch(e){console.warn('Bundled FFmpeg is unavailable:',e.message);}
 choices.push(process.env.OPEN_IPTV_FFMPEG,
  path.join(app.getPath('userData'),'tools',executable),
  ...(process.platform==='darwin'?['/opt/homebrew/bin/ffmpeg','/usr/local/bin/ffmpeg','/opt/local/bin/ffmpeg']:[]),
  ...(process.platform==='win32'?['C:\\ffmpeg\\bin\\ffmpeg.exe']:[]),
  'ffmpeg');
 for(const cmd of [...new Set(choices.filter(Boolean))]){
  try{
   const result=spawnSync(cmd,['-version'],{windowsHide:true,timeout:3500,stdio:'ignore'});
   if(!result.error&&result.status===0){resolvedFfmpeg=cmd;return cmd;}
  }catch(e){console.warn('FFmpeg unavailable:',cmd,e.message);}
 }
 resolvedFfmpeg=null;return null;
}
function requireFfmpeg(){
 const found=ffmpegPath();
 if(!found)throw Error('Không tìm thấy FFmpeg tích hợp. Hãy cài lại bản Open IPTV Pro Full đúng kiến trúc của máy.');
 return found;
}

// Use one tested engine for single shots and batch shots.  The engine also
// retries through /stream, matching WebView playback and retaining diagnostics.
const {createSnapshotEngine}=require('./snapshot.cjs');
async function makeSnapshot(url,label){
 const ffmpeg=requireFfmpeg();
 const engine=createSnapshotEngine({
  ffmpeg,
  folder:path.join(app.getPath('userData'),'snapshots'),
  proxy:proxyUrl,
  baseUrl:()=>`http://127.0.0.1:${port}/snapshot?key=${secret}&file=`,
 });
 return engine(url,label);
}

const batchJobs=createBatchJobs({
  check:url=>/^https?:\/\//i.test(url)?checkRepeated(url,{fastPositive:true}):Promise.resolve({status:'uncertain',reason:'RTSP/RTMP/UDP không hỗ trợ bộ kiểm tra HTTP'}),
  snapshot:(url,label)=>makeSnapshot(url,label),
});

async function readCompatibleBackup(filename){
 if(typeof filename!=='string'||!path.isAbsolute(filename)||!/\.(iptvbackup|json)$/i.test(filename))throw Error('Đường dẫn Backup không hợp lệ');
 if(filename.toLowerCase().endsWith('.iptvbackup'))return backupService.readBackup(filename);
 const stat=await fs.promises.stat(filename);
 if(!stat.isFile()||stat.size>legacyBackup.MAX_BYTES)throw Error('File Backup JSON quá lớn.');
 const bytes=await fs.promises.readFile(filename);
 const parsed=legacyBackup.parse(bytes.toString('utf8'));
 const clean=backupService.checkedStorage(parsed.entries);
 const state=JSON.parse(clean['open-iptv-pro-4']||clean['streamleaf-3']);
 const data={magic:backupService.MAGIC,formatVersion:backupService.FORMAT_VERSION,createdAt:parsed.summary.createdAt,
   appVersion:parsed.appVersion,includesSnapshots:false,storage:clean,snapshotFiles:{}};
 return {data,sha256:createHash('sha256').update(bytes).digest('hex'),summary:{createdAt:data.createdAt,appVersion:data.appVersion,
   sourceCount:state.sources.length,channelCount:state.channels.length,images:0,bytes:bytes.length,legacy:true}};
}

function setupIPC(){
 ipcMain.handle('cast:discover',async()=>castService.discover());
 ipcMain.handle('airplay:discover',async()=>discoverAirplay());
 ipcMain.handle('cast:play',async(_e,deviceId,url,title)=>castService.play(deviceId,url,title));
 ipcMain.handle('cast:stop',async()=>castService.stop());
 ipcMain.handle('cast:status',()=>castService.status());
 ipcMain.handle('cast:lan',async(_e,url)=>{urlOK(url);await castService.stop();const result=await castService.relay.start(url);return {page:result.page};});
 ipcMain.handle('airplay:open',async(_e,url)=>{
  if(process.platform!=='darwin')throw Error('AirPlay Safari chỉ hỗ trợ macOS');
  return castService.openAirplay(url,async page=>{
   await new Promise((resolve,reject)=>{
    const child=spawn('/usr/bin/open',['-a','Safari',page],{windowsHide:true,stdio:'ignore'});
    child.once('error',reject);child.once('close',code=>code===0?resolve():reject(Error('Không mở được Safari')));
   });
  });
 });
 ipcMain.handle('playback:fallback:start',async(_e,url)=>{
   urlOK(url);requireFfmpeg();
   const {id}=await playbackFallback.start(url);
   return {id,url:`http://127.0.0.1:${port}/playback-fallback?key=${secret}&id=${encodeURIComponent(id)}&file=index.m3u8`};
 });
 ipcMain.handle('playback:fallback:stop',(_e,id)=>playbackFallback.stop(id));
 ipcMain.handle('playback:fallback:status',()=>playbackFallback.status());
 ipcMain.handle('timeshift:start',(_e,url,minutes=10)=>{
   urlOK(url);requireFfmpeg();const {id}=timeshift.start(url,minutes);
   return {id,url:`http://127.0.0.1:${port}/buffer?key=${secret}&id=${id}&file=rolling.m3u8`};
 });
 ipcMain.handle('timeshift:stop',()=>{timeshift.stop();return true;});
 ipcMain.handle('timeshift:status',()=>timeshift.status());
 ipcMain.handle('reminder:notify',(_e,title,body)=>{const {Notification}=require('electron');if(!Notification.isSupported())return false;new Notification({title:String(title).slice(0,100),body:String(body).slice(0,200)}).show();return true;});
 ipcMain.handle('epg:fetch',async(_e,url)=>await fetchGuide(url));
 ipcMain.handle('update:check',async()=>await updates.checkForUpdates());
 ipcMain.handle('update:status',()=>updates.snapshot());
 ipcMain.handle('update:download',async()=>await updates.download());
 ipcMain.handle('update:install',()=>updates.install());
 ipcMain.handle('update:openDownloaded',async()=>{if(updates.snapshot().phase!=='manual-ready'||!updates.downloadedPath)throw Error('Chưa có bộ cài đã xác minh');return shell.openPath(updates.downloadedPath);});
 ipcMain.handle('update:openRelease',async()=>shell.openExternal('https://github.com/trisanghy/open-iptv-pro/releases/latest'));
 ipcMain.handle('update:openReleases',async()=>shell.openExternal('https://github.com/trisanghy/open-iptv-pro/releases')); 
 ipcMain.handle('app:capabilities',()=>({native:true,platform:process.platform,ffmpegExists:!!ffmpegPath(),snapshotBase:`http://127.0.0.1:${port}/snapshot?key=${secret}&file=`,version:app.getVersion()}));
 ipcMain.handle('source:readFile', async()=>{
  const r=await dialog.showOpenDialog(webWindow,{title:'Chọn playlist M3U',properties:['openFile'],filters:[{name:'Danh sách IPTV',extensions:['m3u','m3u8','txt']},{name:'Tất cả',extensions:['*']} ]});
  if(r.canceled||!r.filePaths[0])return null;const p=r.filePaths[0];const data=fs.readFileSync(p);if(data.length>MAX_PLAYLIST)throw new Error('File quá lớn');
  return {name:path.basename(p),content:data.toString('utf8')};
 });
 ipcMain.handle('source:readUrl',async(_e,url)=>({content:await readURL(url)}));
 ipcMain.handle('media:proxy',(_e,url)=>{urlOK(url);return proxyUrl(url);});
 ipcMain.handle('media:kind',async(_e,url)=>{
   urlOK(url);const cached=mediaKindCache.get(url);if(cached&&Date.now()-cached.at<15*60_000)return cached.value;const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),5000);
   try{
     const r=await fetch(url,{headers:{Range:'bytes=0-2047','User-Agent':'Open-IPTV-Pro/4.23.36'},signal:ctrl.signal});
     const ct=r.headers.get('content-type')||'';let sample='';
     if(r.body){const rd=r.body.getReader();const part=await rd.read();if(part.value)sample=Buffer.from(part.value).subarray(0,2048).toString('utf8');await rd.cancel();}
     const value=inspectMedia({url,contentType:ct,sample:Buffer.from(sample),acceptRanges:r.headers.get('accept-ranges')||''});
     if(mediaKindCache.size>150)mediaKindCache.clear();mediaKindCache.set(url,{at:Date.now(),value});return value;
   }catch{return {hls:false};}finally{clearTimeout(t);}
 });
 ipcMain.handle('link:check',async(_e,url)=>{urlOK(url);return await checkRepeated(url,{fastPositive:true});});
 ipcMain.handle('batch:start',(_e,params)=>batchJobs.start(params));
 ipcMain.handle('batch:status',(_e,id,offset)=>batchJobs.status(id,offset));
 ipcMain.handle('batch:cancel',(_e,id)=>batchJobs.cancel(id));
 ipcMain.handle('snapshot:make',async(_e,url,name)=>await makeSnapshot(url,name));
 ipcMain.handle('file:export',async(_e,name,content)=>{
  const r=await dialog.showSaveDialog(webWindow,{defaultPath:name||'iptv.m3u',filters:[{name:'IPTV Playlist',extensions:['m3u']}]});if(r.canceled||!r.filePath)return null;
  const p=r.filePath;const temp=p+'.tmp-'+randomBytes(4).toString('hex');fs.writeFileSync(temp,content,'utf8');fs.renameSync(temp,p);return p;
 });

 // DVR recorder owns a separate FFmpeg process and never replaces the player.
 ipcMain.handle('dvr:list',()=>dvr.list());
 ipcMain.handle('dvr:create',(_e,details)=>{requireFfmpeg();return dvr.create(details);});
 ipcMain.handle('dvr:stop',(_e,id)=>dvr.stopJob(id));
 ipcMain.handle('dvr:chooseDirectory',(_e,folder)=>{
  if(typeof folder!=='string'||folder.length>1024||!path.isAbsolute(folder))throw Error('Thư mục DVR không hợp lệ');
  return dvr.chooseDirectory(folder);
 });
 ipcMain.handle('dvr:openDirectory',()=>shell.openPath(dvr.list().directory));
 ipcMain.handle('dvr:reveal',(_e,id)=>{const job=dvr.list().jobs.find(x=>x.id===id);
  if(!job?.file||!fs.existsSync(job.file))throw Error('Không tìm thấy file ghi hình.');return shell.showItemInFolder(job.file);});
 ipcMain.handle('epg:importFile',(_e,file)=>{
  if(typeof file!=='string'||!path.isAbsolute(file)||!/\.(xml|xmltv|gz)$/i.test(file))throw Error('Đường dẫn EPG không hợp lệ');
  return readGuideFile(file);
 });
 // Backup includes localStorage, persisted DVR schedules and optional on-disk JPEG snapshots.
 ipcMain.handle('backup:export',async(_e,storage,includeSnapshots,filename)=>{
  if(typeof filename!=='string'||!path.isAbsolute(filename)||!filename.toLowerCase().endsWith('.iptvbackup'))throw Error('Đường dẫn Backup không hợp lệ');
  const {output,summary}=await backupService.createBackup({...storage,'open-iptv-pro-dvr-v1':dvr.exportPending()},path.join(app.getPath('userData'),'snapshots'),{includeSnapshots,appVersion:app.getVersion()});
  await backupService.saveAtomic(filename,output);return {canceled:false,file:filename,...summary};
 });
 ipcMain.handle('backup:inspect',async(_e,filename)=>{
  pendingBackup=null;pendingRestore=null;
  if(typeof filename!=='string'||!path.isAbsolute(filename)||!/\.(iptvbackup|json)$/i.test(filename))throw Error('Đường dẫn Backup không hợp lệ');
  const {sha256,summary,data}=await readCompatibleBackup(filename);
  if(data.storage['open-iptv-pro-dvr-v1'])summary.recordingSchedules=dvr.prepareImport(data.storage['open-iptv-pro-dvr-v1']).length;
  const token=randomBytes(18).toString('hex');pendingBackup={path:filename,sha256,token};
  return {canceled:false,token,...summary};
 });
 ipcMain.handle('backup:restore',async(_e,token)=>{
  if(!pendingBackup||pendingBackup.token!==token)throw Error('Phiên khôi phục không hợp lệ.');
  const picked=pendingBackup;pendingBackup=null;
  const {data,sha256}=await readCompatibleBackup(picked.path);
  if(sha256!==picked.sha256)throw Error('File đã bị thay đổi sau khi xem trước.');
  const snapshotDir=path.join(app.getPath('userData'),'snapshots');
  const restored=await backupService.restoreBackup(data,snapshotDir);
  const finishToken=randomBytes(18).toString('hex');
  pendingRestore={token:finishToken,paths:restored.createdFiles,snapshotDir,dvrData:restored.storage['open-iptv-pro-dvr-v1']||null};
  return {storage:restored.storage,finishToken};
 });
 ipcMain.handle('backup:finish',async(_e,token,success)=>{
  if(!pendingRestore||pendingRestore.token!==token)return false;
  const state=pendingRestore;pendingRestore=null;
  if(success===true&&state.dvrData)dvr.importPending(state.dvrData);
  if(success!==true)await backupService.discardImportedImages(state.paths,state.snapshotDir);
  return true;
 });
 ipcMain.handle('smart:countries',()=>smartDiscovery.listCountries());
 ipcMain.handle('smart:country',(_e,code)=>smartDiscovery.loadCountry(code));
 ipcMain.handle('smart:catalog-options',(_e,kind)=>smartDiscovery.listCatalogOptions(kind));
 ipcMain.handle('smart:load',(_e,spec)=>smartDiscovery.loadCatalog(spec));
 ipcMain.handle('smart:check',async(_e,url)=>{const safe=smartDiscovery.safeStreamURL(url);return checkRepeated(safe.href,{fetcher:smartDiscovery.safeStreamFetch,delayMs:250});});
 ipcMain.handle('source:listRepo',async(_e,url)=>await listPublicPlaylists(url));
 ipcMain.handle('system:openVLC',()=>shell.openExternal('https://www.videolan.org/vlc/'));
}
function createWindow(){
 webWindow=new BrowserWindow({width:1360,height:850,minWidth:980,minHeight:640,backgroundColor:nativeTheme.shouldUseDarkColors?'#080e15':'#f3f6fb',title:'Open IPTV Pro 4.23.36',icon:path.join(__dirname,'../assets/icon.png'),webPreferences:{preload:path.join(__dirname,'preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true}});
 webWindow.loadFile(path.join(__dirname,'../renderer/index.html'));
 webWindow.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 webWindow.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith('file:'))event.preventDefault();});
}
app.whenReady().then(async()=>{playbackFallback=createPlaybackFallback({baseDir:app.getPath('userData'),ffmpegPath:ffmpegPath()||'ffmpeg',logger:()=>{}});timeshift=createTimeshift({baseDir:app.getPath('userData'),ffmpegPath:ffmpegPath()||'ffmpeg',logger:()=>{}});
 dvr=createRecordingScheduler({baseDir:app.getPath('userData'),ffmpegPath:ffmpegPath()||'ffmpeg',logger:msg=>console.warn('DVR:',msg)});
 dvr.startMonitoring();await startProxy();
 updates=new UpdateManager({app,updater:null,check:require('./webview-updates.cjs').checkWebViewRelease});
 updates.on('status',s=>{if(webWindow&&!webWindow.isDestroyed())webWindow.webContents.send('update:status',s);});
 setupIPC();createWindow();console.log('OPEN_IPTV_BACKEND_READY:'+JSON.stringify({port,secret}));app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});}).catch(e=>{dialog.showErrorBox('Open IPTV Pro lỗi khởi chạy',String(e.stack||e));app.quit();});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
app.on('before-quit',()=>{try{dvr?.shutdown();}catch{}try{timeshift?.stop();}catch{}try{playbackFallback?.stop();}catch{}void castService.stop().catch(()=>{});try{server.close();}catch{}});
