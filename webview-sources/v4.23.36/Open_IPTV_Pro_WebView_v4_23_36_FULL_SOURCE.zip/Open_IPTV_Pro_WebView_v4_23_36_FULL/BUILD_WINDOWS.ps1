# Open IPTV Pro WebView v4.23.36 — Windows NSIS build.
# Run through BUILD_WINDOWS.cmd or from PowerShell using -ExecutionPolicy Bypass -File.
# NEVER calls electron-builder (WebView is Tauri 2).
param(
  [switch] $SkipTests,
  [switch] $NoOpen
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = $PSScriptRoot
$downloads = Join-Path $env:USERPROFILE 'Downloads'
if (-not (Test-Path -LiteralPath $downloads)) { New-Item -ItemType Directory -Force -Path $downloads | Out-Null }
$log = Join-Path $downloads 'OpenIPTV_WebView_Windows_Build.log'
$transcript = $false

function Fail([string]$message) { throw $message }
function Run([string]$title, [string]$command, [string[]]$arguments) {
  Write-Host "`n>>> $title" -ForegroundColor Cyan
  Write-Host "    $command $($arguments -join ' ')"
  & $command @arguments
  $exitCode = $LASTEXITCODE
  if ($exitCode -ne 0) { Fail "$title : exit $exitCode" }
}
function Find-Exe([string[]]$names) {
  foreach ($name in $names) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
  }
  return $null
}
try {
  Start-Transcript -Path $log -Append -ErrorAction Stop | Out-Null
  $transcript = $true
  Write-Host '=== OPEN IPTV PRO WEBVIEW 4.23.36 - WINDOWS (Tauri 2) ===' -ForegroundColor Green
  Write-Host "Source: $root"
  Write-Host "Log: $log"
  if (-not [Environment]::Is64BitOperatingSystem -or -not [Environment]::Is64BitProcess) {
    Fail 'Can Windows x64 va PowerShell 64-bit.'
  }
  if (-not (Test-Path -LiteralPath (Join-Path $root 'package.json'))) {
    Fail 'Khong tim thay package.json o thu muc WebView. Vui long giai nen ZIP day du, khong build tu thu muc scripts.'
  }
  $pkg = Get-Content -LiteralPath (Join-Path $root 'package.json') -Raw | ConvertFrom-Json
  if ($pkg.name -ne 'open-iptv-pro-webview-full') {
    Fail "Day khong phai project WebView Tauri ($($pkg.name)). Khong dung BUILD_WINDOWS.bat Electron trong repo root."
  }
  foreach ($required in @('src-tauri\tauri.conf.json','src-tauri\Cargo.toml','frontend\index.html','scripts\prepare.mjs')) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $required))) { Fail "Thieu file nguon: $required" }
  }
  $drive = [System.IO.Path]::GetPathRoot($root)
  if ($drive -match '^[A-Z]:\\$') {
    $driveInfo = New-Object System.IO.DriveInfo($drive)
    if ($driveInfo.AvailableFreeSpace -lt 10GB) { Fail "Can it nhat 10GB trong tren o $drive" }
  }
  # VS C++ Build Tools and WebView2 are native prerequisites (Rust/MSVC build).
  $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
  if (Test-Path -LiteralPath $vswhere) {
    $vsRoot = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($LASTEXITCODE -ne 0 -or -not $vsRoot) { Fail 'Thieu Visual Studio C++ Build Tools: chon Desktop development with C++.' }
    Write-Host "VS C++ Build Tools: $vsRoot"
  } else {
    Write-Warning 'Chua tim thay vswhere. Neu Rust bao loi link.exe, can Visual Studio Build Tools + Desktop development with C++.'
  }
  $node = Find-Exe @('node.exe', 'node')
  $npm = Find-Exe @('npm.cmd', 'npm')
  if (-not $node -or -not $npm) {
    Fail 'Chua co Node.js/npm. Cai Node.js LTS tu https://nodejs.org/ (Node 22), mo Terminal moi va chay lai.'
  }
  Run 'Node version' $node @('--version')
  $rustBin = Join-Path $env:USERPROFILE '.cargo\bin'
  if (Test-Path $rustBin) { $env:PATH = "$rustBin;$env:PATH" }
  $cargo = Find-Exe @('cargo.exe','cargo')
  if (-not $cargo) {
    Fail 'Chua cai Rust. Cai tu https://rustup.rs/ chon default MSVC, mo Terminal moi va build lai.'
  }
  Run 'Cargo version' $cargo @('--version')
  $rustup = Find-Exe @('rustup.exe','rustup')
  if ($rustup) { Run 'Kiem tra target Windows x64 MSVC' $rustup @('target','add','x86_64-pc-windows-msvc') }
  Set-Location -LiteralPath $root
  Write-Host "`n[1/5] npm dependencies (log chi tiet, khong an tien trinh)" -ForegroundColor Yellow
  if (Test-Path -LiteralPath (Join-Path $root 'package-lock.json')) {
    Run 'npm ci' $npm @('ci','--no-audit','--no-fund','--foreground-scripts','--loglevel=info','--fetch-retries=1','--fetch-timeout=90000')
  } else {
    Run 'npm install' $npm @('install','--no-audit','--no-fund','--foreground-scripts','--loglevel=info','--fetch-retries=1','--fetch-timeout=90000')
  }
  if (-not $SkipTests) {
    Write-Host '[2/5] Unit tests' -ForegroundColor Yellow
    Run 'Test Chromium logic' $npm @('run','test:original')
    Run 'Test WebView logic and bridge' $npm @('run','test:bridge')
  } else { Write-Warning '[2/5] Bo qua test theo yeu cau nguoi dung.' }
  Write-Host '[3/5] Bundling FFmpeg/FFprobe, Node runtime, Cast dependencies' -ForegroundColor Yellow
  # npm run assets is deliberately an explicit stage, not an npm install hook.
  Run 'Generate native binaries' $npm @('run','assets')
  $npx = Find-Exe @('npx.cmd','npx')
  if (-not $npx) { Fail 'Khong tim thay npx.cmd; kiem tra cai Node.' }
  Write-Host '[4/5] Tauri 2 Windows x64 NSIS installer - KHONG chay electron-builder' -ForegroundColor Yellow
  Run 'Tauri build' $npx @('--no-install','tauri','build','--bundles','nsis','--target','x86_64-pc-windows-msvc')
  $nsis = Join-Path $root 'src-tauri\target\x86_64-pc-windows-msvc\release\bundle\nsis'
  if (-not (Test-Path $nsis)) { $nsis = Join-Path $root 'src-tauri\target\release\bundle\nsis' }
  $exe = @(Get-ChildItem -LiteralPath $nsis -Filter '*.exe' -File -ErrorAction SilentlyContinue)
  if ($exe.Count -eq 0) { Fail "Tauri build khong tao file NSIS .exe tai: $nsis" }
  Write-Host '[5/5] Copy output to Downloads' -ForegroundColor Yellow
  $output = Join-Path $downloads 'OpenIPTV_WebView_FULL_Setup'
  New-Item -ItemType Directory -Force -Path $output | Out-Null
  foreach ($file in $exe) { Copy-Item -LiteralPath $file.FullName -Destination $output -Force; Write-Host "Created: $(Join-Path $output $file.Name)" -ForegroundColor Green }
  Write-Host 'SUCCESS: WebView NSIS installer created.' -ForegroundColor Green
  if (-not $NoOpen) { Start-Process explorer.exe -ArgumentList "`"$output`"" }
  exit 0
} catch {
  Write-Host "`nBUILD FAILED: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Log: $log" -ForegroundColor Yellow
  Write-Host 'Khong xoa app cu, du lieu nguoi dung hay thu muc repo.'
  exit 1
} finally {
  if ($transcript) { try { Stop-Transcript | Out-Null } catch {} }
}
