#!/bin/bash
# Đẩy đúng mã nguồn WebView v4.23.36 full Electron feature sync vào nhánh thử nghiệm hiện có.
# Chỉ thay đổi experiments/webview-full và workflow WebView, không sửa main/Electron.
set -euo pipefail
BRANCH='experiment/native-webview-ffmpeg'
REMOTE='https://github.com/trisanghy/open-iptv-pro.git'
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_PARENT="$HOME/Downloads"

fail() { printf '\n[LỖI] %s\n' "$*" >&2; exit 1; }
command -v git >/dev/null 2>&1 || fail 'Chưa có Git. Trên Mac: xcode-select --install'
command -v rsync >/dev/null 2>&1 || fail 'Không có rsync trên máy.'
[ -s "$SOURCE_DIR/package.json" ] || fail 'Thiếu mã nguồn WebView package.json. Hãy giải nén lại gói ZIP.'
[ -f "$SOURCE_DIR/frontend/backup-ui.js" ] || fail 'Thiếu giao diện Backup/Restore.'
[ -f "$SOURCE_DIR/frontend/dvr-ui.js" ] && [ -f "$SOURCE_DIR/frontend/smart-discovery-ui.js" ] || fail 'Thiếu module DVR/Smart Discovery mới.'
[ -f "$SOURCE_DIR/backend/recording-scheduler.cjs" ] || fail 'Thiếu backend DVR.'
grep -q '"version": "4.23.36"' "$SOURCE_DIR/package.json" || fail 'Không đúng mã WebView v4.23.36.'
mkdir -p "$TARGET_PARENT"

# Chỉ cảnh báo nếu tài khoản CLI hiện tại khác chủ repo; không tự đổi/xóa xác thực.
if command -v gh >/dev/null 2>&1; then
  GH_USER="$(gh api user --jq .login 2>/dev/null || true)"
  if [ -n "$GH_USER" ] && [ "$GH_USER" != 'trisanghy' ]; then
    fail "GitHub CLI đang dùng '$GH_USER', không phải 'trisanghy'. Chạy 'gh auth switch --user trisanghy' nếu đã thêm tài khoản, rồi thử lại."
  fi
  if [ "$GH_USER" = 'trisanghy' ]; then gh auth setup-git >/dev/null 2>&1 || true; fi
fi

printf '\n=== PUBLISH WEBVIEW 4.23.36 FULL SYNC / WIN + MAC ===\n'
printf 'Repo: %s\nNhánh: %s\n' "$REMOTE" "$BRANCH"
printf '[1/5] Kiểm tra nhánh GitHub và tải phiên bản mới nhất...\n'
# Clone MỚI đúng nhánh có sẵn; không động đến thư mục làm việc/nhánh main của người dùng.
WORK_DIR="$(mktemp -d "$TARGET_PARENT/OpenIPTV-WebView-GitPublish.XXXXXX")"
REPO="$WORK_DIR/repo"
printf 'Thư mục làm việc: %s\n' "$WORK_DIR"
if ! git clone --single-branch --branch "$BRANCH" "$REMOTE" "$REPO"; then
  fail "Không clone được nhánh '$BRANCH'. Hãy kiểm tra Internet, quyền truy cập GitHub và tên nhánh. Không có file nào được push."
fi
cd "$REPO"
[ "$(git branch --show-current)" = "$BRANCH" ] || fail "Đã checkout sai nhánh, dừng an toàn."
[ -z "$(git status --porcelain)" ] || fail 'Nhánh vừa clone không sạch, dừng an toàn.'

printf '[2/5] Đồng bộ source WebView (giữ file khác có sẵn trong nhánh)...\n'
mkdir -p experiments/webview-full .github/workflows
rsync -a \
  --exclude '/.git/' \
  --exclude '/node_modules/' \
  --exclude '/backend/node_modules/' \
  --exclude '/src-tauri/target/' \
  --exclude '/src-tauri/gen/' \
  --exclude '/src-tauri/binaries/' \
  --exclude '/node-cache/' \
  --exclude '/PUSH_GITHUB_MAC.command' \
  "$SOURCE_DIR/" experiments/webview-full/
cp "$SOURCE_DIR/.github/workflows/build-webview-full.yml" \
  .github/workflows/build-native-webview-v42335.yml

# Dọn workflow WebView v4.23.12 trước đây để chỉ chạy workflow mới.
PREVIOUS_WF='.github/workflows/build-native-webview-v42312.yml'
if [ -f "$PREVIOUS_WF" ] && grep -Fq 'WebView Full v4.23.12' "$PREVIOUS_WF"; then
  rm "$PREVIOUS_WF"
  printf 'Đã bỏ workflow cũ 4.23.12 (chỉ trong nhánh WebView).\n'
fi
# Dọn workflow WebView 4.22 do chính bộ cũ tạo ra (nếu còn), KHÔNG đụng workflow Electron khác.
OLD_WF='.github/workflows/build-native-webview-v422.yml'
if [ -f "$OLD_WF" ] && grep -Fq 'name: WebView Full v4.22.0' "$OLD_WF"; then
  rm "$OLD_WF"
  printf 'Đã bỏ workflow WebView 4.22 cũ để tránh build trùng.\n'
fi
printf '[3/5] Stage chỉ WebView và workflow riêng; không thêm code Chromium ở gốc...\n' 
git add -A -- experiments/webview-full
git add -- .github/workflows/build-native-webview-v42335.yml
if git ls-files --error-unmatch .github/workflows/build-native-webview-v42312.yml >/dev/null 2>&1; then git add -u -- .github/workflows/build-native-webview-v42312.yml; fi
# Nếu workflow 4.22 được xóa ở trên, stage deletion an toàn.
if git ls-files --error-unmatch .github/workflows/build-native-webview-v422.yml >/dev/null 2>&1; then git add -u -- .github/workflows/build-native-webview-v422.yml; fi
if git diff --cached --quiet; then
  printf '\nNhánh %s đã có đúng nội dung này, không cần push thêm.\n' "$BRANCH"
  exit 0
fi
printf 'Thống kê thay đổi:\n'
git diff --cached --stat
if ! git var GIT_AUTHOR_IDENT >/dev/null 2>&1; then
  fail "Git chưa cấu hình tên/email commit. Chạy 'git config --global user.name <tên>' và 'git config --global user.email <email GitHub>' rồi chạy lại."
fi

printf '[4/5] Commit bản WebView v4.23.36...\n'
git commit -m 'feat(webview): v4.23.36 full Electron feature parity, DVR, themes and backup'
printf '[5/5] Push đúng nhánh từ commit mới (KHÔNG force)...\n'
if ! git push origin "HEAD:refs/heads/$BRANCH"; then
  fail "Push không thành công. Chưa thay đổi main. Kiểm tra tài khoản/quyền GitHub, hoặc nhánh có commit mới. Có thể xem commit tại $REPO"
fi
printf '\nĐÃ PUSH THÀNH CÔNG!\nRepo: %s\nNhánh: %s\nMã nguồn: experiments/webview-full/\nWorkflow: .github/workflows/build-native-webview-v42335.yml\n' "$REMOTE" "$BRANCH"
printf 'Xem: https://github.com/trisanghy/open-iptv-pro/tree/experiment/native-webview-ffmpeg\n'
